//Header file for Basic shapes in the game
#pragma once
#include "shape.h"

////////////////////////////////////////////////////  class Rect  ///////////////////////////////////////
//Rectanle class
/*							wdth
					---------------------
					|					|
			hght    |		 x			|     x is the reference point of the rectangle
					|					|
					--------------------
*/


class Rect:public shape
{
	int hght, wdth;	//height and width of the recangle
public:
	Rect(game* r_pGame, point ref, int r_hght, int r_wdth);
	int getheight();
	int getwidth();
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);
	point getRef()const;
};


////////////////////////////////////////////////////  class circle  ///////////////////////////////////////
//Reference point of the circle is its center
class circle :public shape
{
	//Add data memebrs for class circle
	int rad;
public:	
	circle(game* r_pGame, point ref, int r);	//add more parameters for the constructor if needed
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);
	point getRef()const;
};

class Triangle : public shape
{
	int px1, py1, px2, py2, px3, py3;
	double side;
public:
	Triangle(game* r_pGame, point ref, int px_1, int py_1, int px_2, int py_2, int px_3, int py_3, double side);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);
	point getRef()const;
};
