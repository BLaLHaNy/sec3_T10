#pragma once
#include "Basicshapes.h"


////////////////////////////////////////////////////  class Sign  ///////////////////////////////////////
//This class reprsents the composite shape "sign"
//The sign is composed of 2 Recatngles
/*				

					 ------------------
					|				   |
					|		 x		   |     x is the reference point of the Sign shape
					|			       |
					 ------------------
						   |   |
						   |   |
						   | . |
						   |   |
						   |   |
							---
*/

//Note: sign reference point is the center point of the top rectangle
class Sign :public shape
{
	Rect* base;
	Rect* top;
public:
	Sign(game* r_pGame, point ref);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);

};

class House : public shape
{
	Rect* front;
	Triangle* roof;
	circle* window;
public:
	House(game* r_pGame, point ref);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
};

class Car : public shape
{
	Rect* body;
	circle* backwheel;
	circle* frontwheel;
	Triangle* frontbody;
public:
	Car(game* r_pGame, point ref);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
};

class Tree : public shape
{
	Triangle* leaf;
	Rect* bark;
public:
	Tree(game* r_pGame, point ref);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
};

class Lollipop : public shape
{
	Rect* stick;
	circle* candy;
public:
	Lollipop(game* r_pGame, point ref);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
};

class robot : public shape
{
	Rect* body;
	circle* head;
	Triangle* leg;
public:
	robot(game* r_pGame, point ref);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
};

class key : public shape
{
	Rect* body;
	circle* head;
	Triangle* leg1;
	Triangle* leg2;
public:
	key(game* r_pGame, point ref);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
};
class pencil : public shape
{
	Rect* body;
	circle* tail;
	Triangle* tip;
public:
	pencil(game* r_pGame, point ref);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
};
