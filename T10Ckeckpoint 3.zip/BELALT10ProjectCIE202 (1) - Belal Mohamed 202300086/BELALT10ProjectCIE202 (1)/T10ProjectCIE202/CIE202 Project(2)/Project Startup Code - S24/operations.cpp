#include "operations.h"
#include "game.h"
#include "CompositeShapes.h"

/////////////////////////////////// class operation  //////////////////
operation::operation(game* r_pGame)
{
	pGame = r_pGame;
}


/////////////////////////////////// class operAddSign  //////////////////

operAddSign::operAddSign(game* r_pGame):operation(r_pGame)
{
}
operAddTriangle::operAddTriangle(game* r_pGame):operation(r_pGame)
{
}
operAddcircle::operAddcircle(game* r_pGame) :operation(r_pGame)
{
}
operAddRectangle::operAddRectangle(game* r_pGame):operation(r_pGame)
{
}
operAddHouse::operAddHouse(game* r_pGame) :operation(r_pGame)
{
}
operAddCar::operAddCar(game* r_pGame) :operation(r_pGame)
{
}
operAddTree::operAddTree(game* r_pGame) :operation(r_pGame)
{
}
operAddLollipop::operAddLollipop(game* r_pGame) :operation(r_pGame)
{
}
operAddrobot::operAddrobot(game* r_pGame) :operation(r_pGame)
{
}
operAddkey::operAddkey(game* r_pGame) :operation(r_pGame)
{
}
operAddpencil::operAddpencil(game* r_pGame) :operation(r_pGame)
{
}
operRotate::operRotate(game* r_pGame) :operation(r_pGame)
{
}
operHint::operHint(game* r_pGame) :operation(r_pGame)
{
}
operRefresh::operRefresh(game* r_pGame) :operation(r_pGame)
{
}
operDelete::operDelete(game* r_pGame) :operation(r_pGame)
{
}
operIncrease::operIncrease(game* r_pGame) :operation(r_pGame)
{
}
operDecrease::operDecrease(game* r_pGame) :operation(r_pGame)
{
}
operSelectLevel::operSelectLevel(game* r_pGame) : operation(r_pGame)
{
}
operSave::operSave(game* r_pGame) : operation(r_pGame)
{
}
operflip::operflip(game* r_pGame) : operation(r_pGame)
{
}

void operAddSign::Act()
{
	window* pw = pGame->getWind();

	//TODO:
	// Don't allow adding new shape if there is alreday an active shape

	//align reference point to the nearest grid point
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefX % config.gridSpacing;

	//take the aligned point as the sign shape ref point
	point signShapeRef = { xGrid,yGrid };

	//create a sign shape
	shape* psh = new Sign(pGame, signShapeRef);

	//Add the shape to the grid
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);

}

void operAddTriangle::Act()
{
	window* pw = pGame->getWind();

	//TODO:
	// Don't allow adding new shape if there is alreday an active shape

	//align reference point to the nearest grid point
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefX % config.gridSpacing;

	//take the aligned point as the sign shape ref point
	point signShapeRef = { xGrid,yGrid };

	//create a sign shape
	shape* psh = new Triangle(pGame, signShapeRef, 30, 40, 60, 60, 60, 60, 60);

	//Add the shape to the grid
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);

}


void operAddcircle::Act()
{
	{
		window* pw = pGame->getWind();

		//TODO:
		// Don't allow adding new shape if there is alreday an active shape

		//align reference point to the nearest grid point
		int xGrid = config.RefX - config.RefX % config.gridSpacing;
		int yGrid = config.RefY - config.RefX % config.gridSpacing;

		//take the aligned point as the sign shape ref point
		point signShapeRef = { xGrid,yGrid };


		//create a sign shape
		shape* psh = new circle(pGame, signShapeRef, 50);
		//Add the shape to the grid
		grid* pGrid = pGame->getGrid();
		pGrid->setActiveShape(psh);

	}
}
void operAddRectangle::Act()
{
	window* pw = pGame->getWind();

	//TODO:
	// Don't allow adding new shape if there is alreday an active shape

	//align reference point to the nearest grid point
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefX % config.gridSpacing;

	//take the aligned point as the sign shape ref point
	point signShapeRef = { xGrid,yGrid };

	//create a sign shape
	shape* psh = new Rect(pGame, signShapeRef,60,50);

	//Add the shape to the grid
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);

}


void operAddHouse::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new House(pGame, signShapeRef);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}
void operAddCar::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new Car(pGame, signShapeRef);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}
void operAddTree::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new Tree(pGame, signShapeRef);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}
void operAddLollipop::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new Lollipop(pGame, signShapeRef);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}
void operAddrobot::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new robot(pGame, signShapeRef);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}
void operAddkey::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new key(pGame, signShapeRef);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}
void operAddpencil::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new pencil(pGame, signShapeRef);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}
operDeleteShape::operDeleteShape(game* r_pGame) :operation(r_pGame)
{
}
void operDeleteShape::Act()
{
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	pGrid->Delete();
}

void operRotate::Act()
{
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	shape* psh = pGrid->getActiveShape();
	if (psh != nullptr)
		psh->rotate();
}
void operflip::Act()
{
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	shape* psh = pGrid->getActiveShape();
	if (psh != nullptr)
		psh->flip();
}
void operHint::Act()
{


}
void operRefresh::Act()
{


	/*pGame->setlives();*/
}
void operDelete::Act() {

}
void operIncrease::Act()
{

}
void operDecrease::Act()
{

}
void operSelectLevel::Act()
{
	window* pw = pGame->getWind();
	pGame->SelecLvl();
}
void operSave::Act()
{

}
operResizeUp::operResizeUp(game* r_pGame) :operation(r_pGame)
{
}
operResizeDown::operResizeDown(game* r_pGame) :operation(r_pGame)
{
}
void operResizeUp::Act() {
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	shape* psh = pGrid->getActiveShape();
	if (psh != nullptr)
		psh->resizeUp();
}

void operResizeDown::Act() {
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	shape* psh = pGrid->getActiveShape();
	if (psh != nullptr)
		psh->resizeDown();
}