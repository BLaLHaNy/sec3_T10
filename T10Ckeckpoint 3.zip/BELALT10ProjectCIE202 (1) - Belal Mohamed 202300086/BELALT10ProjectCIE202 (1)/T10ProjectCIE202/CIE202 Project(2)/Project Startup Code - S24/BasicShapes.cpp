#include "BasicShapes.h"
#include "gameConfig.h"
#include "game.h"

#include"windows.graphics.h"
#include"CMUgraphicsLib/CMUgraphics.h"

////////////////////////////////////////////////////  class Rect  ///////////////////////////////////////

Rect::Rect(game* r_pGame, point ref, int r_hght, int r_wdth):shape(r_pGame,ref)
{
	pGame = r_pGame;
	hght = r_hght;
	wdth = r_wdth;
}

void Rect::draw() const
{
	window* pW = pGame->getWind();	//get interface window
	pW->SetPen(config.penColor, config.penWidth);
	pW->SetBrush(config.fillColor);
	point upperLeft, lowerBottom;
	upperLeft.x = RefPoint.x - wdth / 2;
	upperLeft.y = RefPoint.y - hght / 2;
	lowerBottom.x = RefPoint.x + wdth / 2;
	lowerBottom.y = RefPoint.y + hght / 2;

	pW->DrawRectangle(upperLeft.x  , upperLeft.y, lowerBottom.x , lowerBottom.y , FILLED);
}
int Rect::getheight()
{
	return hght;
}

int Rect::getwidth()
{
	return wdth;
}

void Rect::resizeUp()
{
	hght = hght * 2;
	wdth = wdth * 2;
}

void Rect::resizeDown()
{
	hght = hght / 2;
	wdth = wdth / 2;
}
void Rect::flip()
{
	//nothing occurs on flipping a rectangle

}

void Rect::rotate()
{

	window* pW = pGame->getWind();    //get interface window
	pW->SetPen(config.penColor, config.penWidth);
	pW->SetBrush(config.fillColor);
	point upperLeft, lowerBottom;
	upperLeft.x = RefPoint.x + hght / 2;
	upperLeft.y = RefPoint.y - wdth / 2;
	lowerBottom.x = RefPoint.x - hght / 2;
	lowerBottom.y = RefPoint.y + wdth / 2;

	pW->DrawRectangle(upperLeft.x, upperLeft.y, lowerBottom.x, lowerBottom.y, FILLED);
}
void Rect::move(point p) {
	RefPoint.x += p.x;
	RefPoint.y += p.y;
}
point Rect::getRef()const {
	return RefPoint;
}


////////////////////////////////////////////////////  class circle  ///////////////////////////////////////
//TODO: Add implementation for class circle here
circle::circle(game* r_pGame, point ref, int r) :shape(r_pGame, ref) {
	rad = r;
}


	

void circle::draw() const
{
	window* pW = pGame->getWind();	//get interface window
	pW->SetPen(borderColor, config.penWidth);
	pW->SetBrush(fillColor);
	pW->DrawCircle(RefPoint.x, RefPoint.y, rad, FILLED);
}
void circle::resizeUp()
{
	rad = rad * 2;
}
void circle::resizeDown()
{
	rad = rad / 2;
}
void circle::flip()
{
	//nothing occurs on flipping a circle

}

void circle::rotate()
{
	//nothing occurs on rotating a circle
}


////////////////////////////////////////////////////  class triangle  ///////////////////////////////////////
//TODO: Add implementation for class triangle here


Triangle::Triangle(game* r_pGame, point ref, int px_1, int py_1, int px_2, int py_2, int px_3, int py_3, double side) :shape(r_pGame, ref)
{
	px1 = px_1;
	py1 = py_1;
	px2 = px_2;
	py2 = py_2;
	px3 = px_3;
	py3 = py_3;
	Triangle::side = side;
}
void Triangle::draw() const
{
	window* pW = pGame->getWind();	//get interface window
	int px1 = RefPoint.x;
	int py1 = RefPoint.y - (side * 2 / 3 * sqrt(3) / 2);
	int px2 = RefPoint.x - (0.5 * side);
	int py2 = RefPoint.y + (side * 2 / 3 * sqrt(3) / 2);
	int px3 = RefPoint.x + (0.5 * side);
	int py3 = RefPoint.y + (side * 2 / 3 * sqrt(3) / 2);
	pW->SetPen(borderColor, config.penWidth);
	pW->SetBrush(fillColor);
	pW->SetPen(borderColor, config.penWidth);
	pW->DrawTriangle(px1, py1, px2, py2, px3, py3, FILLED);
}
void Triangle::resizeUp()
{
	side = side * 2;
}

void Triangle::resizeDown()
{
	side = side / 2;
}
void Triangle::flip()
{

	window* pW = pGame->getWind();    //get interface window
	int px1 = RefPoint.x;
	int py1 = RefPoint.y - (side * 2 / 3 * sqrt(3) / 2);
	int px2 = RefPoint.x - (0.5 * side);
	int py2 = RefPoint.y + (side * 2 / 3 * sqrt(3) / 2);
	int px3 = RefPoint.x + (0.5 * side);
	int py3 = RefPoint.y + (side * 2 / 3 * sqrt(3) / 2);
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;
	pW->SetPen(borderColor, config.penWidth);
	pW->SetBrush(fillColor);
	pW->SetPen(borderColor, config.penWidth);
	pW->DrawTriangle(px1, py1, px2, py2, px3, py3, FILLED);
}


void Triangle::rotate()
{

	window* pW = pGame->getWind();    //get interface window
	int px1 = RefPoint.x;
	int py1 = RefPoint.y - (side * 2 / 3 * sqrt(3) / 2);
	int px2 = RefPoint.x - (0.5 * side);
	int py2 = RefPoint.y + (side * 2 / 3 * sqrt(3) / 2);
	int px3 = RefPoint.x + (0.5 * side);
	int py3 = RefPoint.y + (side * 2 / 3 * sqrt(3) / 2);
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	pW->SetPen(borderColor, config.penWidth);
	pW->SetBrush(fillColor);
	pW->SetPen(borderColor, config.penWidth);
	pW->DrawTriangle(px1, py1, px2, py2, px3, py3, FILLED);
}
void Triangle::move(point p) {

}
void circle::move(point p) {

}