#include "CompositeShapes.h"
#include "gameConfig.h"

////////////////////////////////////////////////////  class Sign  ///////////////////////////////////////
Sign::Sign(game* r_pGame, point ref):shape(r_pGame, ref)
{
	//calc the ref point of the Sign base and top rectangles relative to the Sign shape
	point topRef = ref;	//top rect ref is the same as the sign
	point baseRef = { ref.x, ref.y + config.sighShape.topHeight / 2  + config.sighShape.baseHeight / 2  };
	top = new Rect(pGame, topRef, config.sighShape.topHeight, config.sighShape.topWdth );
	base = new Rect(pGame, baseRef, config.sighShape.baseHeight, config.sighShape.baseWdth);
}

void Sign::draw() const
{
	base->draw();
	top->draw();
}
void Sign::resizeUp()
{
	point topRef = RefPoint;
	point baseRef = { RefPoint.x,RefPoint.y + (base->getheight() + top->getheight()) };
	base->setRefPoint(baseRef);
	top->setRefPoint(topRef);
	top->resizeUp();
	base->resizeUp();
}
void Sign::resizeDown()
{
	point topRef = RefPoint;
	point baseRef = { RefPoint.x,RefPoint.y + (base->getheight() / 4 + top->getheight() / 4) };
	base->setRefPoint(baseRef);
	top->setRefPoint(topRef);
	top->resizeDown();
	base->resizeDown();
}
void Sign::flip()
{

	top->flip();
	point baseRef = { RefPoint.x, RefPoint.y - config.sighShape.topHeight / 2 - config.sighShape.baseHeight / 2 };
	base = new Rect(pGame, baseRef, config.sighShape.baseHeight, config.sighShape.baseWdth);
	base->flip();
}
void Sign::rotate()
{
	point topRef = RefPoint;
	top = new Rect(pGame, topRef, config.sighShape.topWdth, config.sighShape.topHeight);
	top->rotate();
	point baseRef = { RefPoint.x - config.sighShape.topHeight / 2 - config.sighShape.baseHeight / 2, RefPoint.y };
	base = new Rect(pGame, baseRef, config.sighShape.baseWdth, config.sighShape.baseHeight);
	base->rotate();
}
void Sign::move(point p) {
	top->move(p);
	base->move(p);
	this->setRefPoint(top->getRef());
}

////////////////////////////////////////////////////  class House  ///////////////////////////////////////

House::House(game* r_pGame, point ref) :shape(r_pGame, ref) {
	point frontref = ref;
	point roofref = { ref.x, ref.y - config.sighShape.topHeight * 1.5  - config.sighShape.baseWdth +20 };
	point windowref = { ref.x,ref.y - config.sighShape.topHeight * 1.5 / 2 - config.sighShape.baseWdth / 3 };
	front = new Rect(pGame, frontref, config.sighShape.topHeight * 1.5, config.sighShape.topWdth*0.8);
	roof = new Triangle(pGame, roofref, ref.x, ref.y - config.sighShape.topHeight * 3/4 - 3 * config.sighShape.baseWdth, ref.x - config.sighShape.topWdth / 2-3 * config.sighShape.baseWdth, ref.y - config.sighShape.topHeight * 1.5 / 2, ref.x + config.sighShape.topWdth / 2, ref.y - config.sighShape.topHeight * 1.5 / 2, 0.86*config.sighShape.topWdth);
	window = new circle(pGame, windowref, config.sighShape.topHeight/2.5);
}
void House::draw() const {
	front->draw();
	roof->draw();
	window->draw();
}
void House::resizeUp()
{

}
void House::resizeDown()
{

}
void House::rotate()
{

}
void House::flip()
{

}

////////////////////////////////////////////////////  class Car  ///////////////////////////////////////

Car::Car(game* r_pGame, point ref) :shape(r_pGame, ref) {
	point bodyref = ref;
	point backwheelref = { ref.x - config.sighShape.topWdth / 2 + 1.2 * config.sighShape.baseWdth,ref.y + config.sighShape.topHeight / 2 + 1.2 * config.sighShape.baseWdth };
	point frontwheelref = { ref.x + config.sighShape.topWdth / 2 - 1.2 * config.sighShape.baseWdth,ref.y + config.sighShape.topHeight / 2 + 1.2 * config.sighShape.baseWdth };
	point frontbodyref = { ref.x+ config.sighShape.topWdth/2,ref.y };
	body = new Rect(pGame, bodyref, config.sighShape.topHeight, config.sighShape.topWdth);
	backwheel = new circle(pGame, backwheelref, 1.2* config.sighShape.baseWdth);
	frontwheel = new circle(pGame, frontwheelref, 1.2* config.sighShape.baseWdth);
	frontbody = new Triangle(pGame, frontbodyref, 3, 3, 3, 3, 3, 3, config.sighShape.topWdth/2.5);
	
}

void Car::draw() const {
	frontwheel->draw();
	body->draw();
	backwheel->draw();
	frontbody->draw();
}
void Car::resizeUp()
{
	point bodyref = RefPoint;
	point backwheelref = { RefPoint.x - body->getwidth() + 0.5 * body->getwidth(),RefPoint.y + body->getheight() + 0.5 * body->getwidth() };
	point frontwheelref = { RefPoint.x + body->getwidth() - 0.5 * body->getwidth(),RefPoint.y + body->getheight() + 0.5 * body->getwidth() };
	point frontbodyref = { RefPoint.x + body->getwidth(),RefPoint.y };
	frontwheel->setRefPoint(frontwheelref);
	body->setRefPoint(bodyref);
	backwheel->setRefPoint(backwheelref);
	frontbody->setRefPoint(frontbodyref);
	frontwheel->resizeUp();
	body->resizeUp();
	backwheel->resizeUp();
	frontbody->resizeUp();

}

void Car::resizeDown()
{
	point bodyref = RefPoint;
	point backwheelref = { RefPoint.x - body->getwidth() / 4 + 0.5 * body->getwidth() / 4,RefPoint.y + body->getheight() / 4 + 0.5 * body->getwidth() / 4 };
	point frontwheelref = { RefPoint.x + body->getwidth() / 4 - 0.5 * body->getwidth() / 4,RefPoint.y + body->getheight() / 4 + 0.5 * body->getwidth() / 4 };
	point frontbodyref = { RefPoint.x + body->getwidth() / 4,RefPoint.y };
	frontwheel->setRefPoint(frontwheelref);
	body->setRefPoint(bodyref);
	backwheel->setRefPoint(backwheelref);
	frontbody->setRefPoint(frontbodyref);
	frontwheel->resizeDown();
	body->resizeDown();
	backwheel->resizeDown();
	frontbody->resizeDown();
}
void Car::flip()
{


	point backwheelref = { RefPoint.x - config.sighShape.topWdth / 2 + 1.2 * config.sighShape.baseWdth,RefPoint.y - config.sighShape.topHeight / 2 - 1.2 * config.sighShape.baseWdth };


	point frontwheelref = { RefPoint.x + config.sighShape.topWdth / 2 - 1.2 * config.sighShape.baseWdth,RefPoint.y - config.sighShape.topHeight / 2 - 1.2 * config.sighShape.baseWdth };


	int py1 = 3;
	int py2 = 3;
	int py3 = 3;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;

	point frontbodyref = { RefPoint.x + config.sighShape.topWdth / 2,RefPoint.y };
	frontbody = new Triangle(pGame, frontbodyref, 3, py1, 3, py2, 3, py3, 40);
	backwheel = new circle(pGame, backwheelref, 1.2 * config.sighShape.baseWdth);
	frontwheel = new circle(pGame, frontwheelref, 1.2 * config.sighShape.baseWdth);
	frontbody->flip();
	body->flip();
	backwheel->flip();
	frontwheel->flip();

}
void Car::rotate()
{

	body->rotate();

	point backwheelref = { RefPoint.x - config.sighShape.topWdth / 2 - 1.2 * config.sighShape.baseWdth,RefPoint.y - config.sighShape.topHeight / 2 + 1.2 * config.sighShape.baseWdth };
	backwheel = new circle(pGame, backwheelref, 1.2 * config.sighShape.baseWdth);
	backwheel->rotate();

	point frontwheelref = { RefPoint.x - config.sighShape.topWdth / 2 - 1.2 * config.sighShape.baseWdth,RefPoint.y + config.sighShape.topHeight / 2 - 1.2 * config.sighShape.baseWdth };
	frontwheel = new circle(pGame, frontwheelref, 1.2 * config.sighShape.baseWdth);
	frontwheel->rotate();

	point frontbodyref = { RefPoint.x ,RefPoint.y + config.sighShape.topWdth / 2 };
	int px1 = 3;
	int px2 = 3;
	int px3 = 3;
	int py1 = 3;
	int py2 = 3;
	int py3 = 3;
	int temp_x = px1, temp_y = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_x;
	py2 = temp_y;
	frontbody = new Triangle(pGame, frontbodyref, px1, py1, px2, py2, px3, py3, config.sighShape.topWdth / 2.5);
	frontbody->rotate();

}
////////////////////////////////////////////////////  class Tree  ///////////////////////////////////////

Tree::Tree(game* r_pGame, point ref) : shape(r_pGame, ref) {
	point barkref = ref;
	point leafref = { ref.x,ref.y - config.sighShape.baseHeight / 2 };
	bark = new Rect(pGame, barkref, config.sighShape.baseHeight, config.sighShape.topWdth / 4);
	leaf = new Triangle(pGame, leafref, ref.x, ref.y - config.sighShape.baseHeight * 3 / 4, ref.x - config.sighShape.topWdth * 1.5, ref.y, ref.x + config.sighShape.topWdth * 1.5, ref.y, config.sighShape.baseHeight * 3 / 4);
}
void Tree::draw() const {
	bark->draw();
	leaf->draw();
}

void Tree::resizeUp()
{
	point barkref = RefPoint;
	point leafref = { RefPoint.x,RefPoint.y - bark->getheight() };
	bark->setRefPoint(barkref);
	leaf->setRefPoint(leafref);
	bark->resizeUp();
	leaf->resizeUp();
}

void Tree::resizeDown()
{
	point barkref = RefPoint;
	point leafref = { RefPoint.x,RefPoint.y - bark->getheight() / 4 };
	bark->setRefPoint(barkref);
	leaf->setRefPoint(leafref);
	bark->resizeDown();
	leaf->resizeDown();
}
void Tree::flip()
{

	bark->flip();
	point leafref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 };


	int py1 = 300 - config.sighShape.baseHeight * 3 / 4;
	int py2 = 300;
	int py3 = 300;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;

	leaf = new Triangle(pGame, leafref, RefPoint.x, py1, RefPoint.x - config.sighShape.topWdth * 1.5, py2, RefPoint.x + config.sighShape.topWdth * 1.5, py3, config.sighShape.baseHeight * 3 / 4);
	leaf->flip();

}
void Tree::rotate() {

	point barkref = RefPoint;
	bark = new Rect(pGame, barkref, config.sighShape.topWdth / 4, config.sighShape.baseHeight);
	bark->rotate();

	point leafref = { RefPoint.x + config.sighShape.baseHeight / 2,RefPoint.y };
	int px1 = 800;
	int py1 = 300 - config.sighShape.baseHeight * 3 / 4;
	int px2 = 800 - config.sighShape.topWdth * 1.5;
	int py2 = 300;
	int px3 = 800 + config.sighShape.topWdth * 1.5;
	int py3 = 300;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	leaf = new Triangle(pGame, leafref, px1, py1, px2, py2, px3, py3, config.sighShape.baseHeight * 3 / 4);
	leaf->rotate();

}
////////////////////////////////////////////////////  class Lollipop  ///////////////////////////////////////

Lollipop::Lollipop(game* r_pGame, point ref) : shape(r_pGame, ref) {
	point stickref = ref;
	point candyref = { ref.x,ref.y - config.sighShape.baseHeight / 2 };
	stick = new Rect(pGame, stickref, config.sighShape.baseHeight*1.5, config.sighShape.baseWdth);
	candy = new circle(pGame, candyref, config.sighShape.topWdth * 3 / 8);
}
void Lollipop::draw() const {
	stick->draw();
	candy->draw();
}

void Lollipop::resizeUp()
{
	point stickref = RefPoint;
	point candyref = { RefPoint.x,RefPoint.y - stick->getheight() };
	stick->setRefPoint(stickref);
	candy->setRefPoint(candyref);
	stick->resizeUp();
	candy->resizeUp();
}

void Lollipop::resizeDown()
{
	point stickref = RefPoint;
	point candyref = { RefPoint.x,RefPoint.y - stick->getheight() / 4 };
	stick->setRefPoint(stickref);
	candy->setRefPoint(candyref);
	stick->resizeDown();
	candy->resizeDown();
}
void Lollipop::flip()
{

	stick->flip();
	point candyref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 };
	candy = new circle(pGame, candyref, config.sighShape.topWdth * 3 / 8);
	candy->flip();



}
void Lollipop::rotate() {
	point stickref = RefPoint;



	stick = new Rect(pGame, stickref, config.sighShape.baseWdth * 1.5, config.sighShape.baseHeight);
	stick->rotate();


	point candyref = { RefPoint.x + config.sighShape.baseHeight / 2 + 25, RefPoint.y };
	candy = new circle(pGame, candyref, config.sighShape.topWdth * 3 / 8);
	candy->rotate();
}


////////////////////////////////////////////////////  class robot  ///////////////////////////////////////

robot::robot(game* r_pGame, point ref) : shape(r_pGame, ref) {
	point bodyref = ref;
	point headref = { ref.x,ref.y - config.sighShape.baseHeight / 2 - config.sighShape.topWdth / 4 };
	point legref = { ref.x ,ref.y + config.sighShape.baseHeight/ 4 +20 };
	body = new Rect(pGame, bodyref, config.sighShape.baseHeight, config.sighShape.topWdth / 2);
	head = new circle(pGame, headref, config.sighShape.topWdth / 4);
	leg = new Triangle(pGame, legref, ref.x - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3, ref.y + config.sighShape.baseHeight / 2, ref.x - config.sighShape.topWdth / 4, ref.y + config.sighShape.baseHeight / 2, ref.x - config.sighShape.topWdth / 4, ref.y + config.sighShape.baseHeight / 4, config.sighShape.baseHeight /1.5 );

}
void robot::draw() const {
	body->draw();
	head->draw();
	leg->draw();
}

void robot::resizeUp()
{
	point bodyref = RefPoint;
	point headref = { RefPoint.x,RefPoint.y - body->getheight() - body->getwidth() };
	point legref = { RefPoint.x, RefPoint.y + body->getheight() };
	body->setRefPoint(bodyref);
	head->setRefPoint(headref);
	leg->setRefPoint(legref);
	body->resizeUp();
	head->resizeUp();
	leg->resizeUp();
}

void robot::resizeDown()
{
	point bodyref = RefPoint;
	point headref = { RefPoint.x,RefPoint.y - body->getheight() / 4 - body->getwidth() / 4 };
	point legref = { RefPoint.x, RefPoint.y + body->getheight() / 4 };
	body->setRefPoint(bodyref);
	head->setRefPoint(headref);
	leg->setRefPoint(legref);
	body->resizeDown();
	head->resizeDown();
	leg->resizeDown();
}

void robot::flip()
{
	body->flip();
	point headref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 + config.sighShape.topWdth / 4 };
	head = new circle(pGame, headref, config.sighShape.topWdth / 4);
	point legref = { RefPoint.x ,RefPoint.y - config.sighShape.baseHeight / 4 - 20 };
	int py1 = 300 + config.sighShape.baseHeight / 2;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;
	leg = new Triangle(pGame, legref, RefPoint.x - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3, py1, RefPoint.x - config.sighShape.topWdth / 4, py2, RefPoint.x - config.sighShape.topWdth / 4, py3, config.sighShape.baseHeight / 1.5);
	leg->flip();
}

void robot::rotate()
{
	point bodyref = RefPoint;
	body = new Rect(pGame, bodyref, config.sighShape.topWdth / 2, config.sighShape.baseHeight);
	body->rotate();

	point headref = { RefPoint.x - config.sighShape.baseHeight / 2 - config.sighShape.topWdth / 4 ,RefPoint.y };
	head = new circle(pGame, headref, config.sighShape.topWdth / 4);
	head->rotate();

	point legref = { RefPoint.x + config.sighShape.baseHeight / 4 + 25,RefPoint.y };
	int px1 = 800 - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3;
	int py1 = 300 + config.sighShape.baseHeight / 2;
	int px2 = 800 - config.sighShape.topWdth / 4;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int px3 = 800 - config.sighShape.topWdth / 4;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	leg = new Triangle(pGame, legref, px1, py1, px2, py2, px3, py3, config.sighShape.baseHeight / 1.5);
	leg->rotate();


}


key::key(game* r_pGame, point ref) : shape(r_pGame, ref) {
	point bodyref = ref;
	point headref = { ref.x,ref.y - config.sighShape.baseHeight / 2 - config.sighShape.baseWdth * 1.2 };
	point leg1ref = { ref.x - config.sighShape.topWdth / 8,ref.y - config.sighShape.baseHeight / 6 };
	point leg2ref = { ref.x - config.sighShape.topWdth / 8,ref.y + config.sighShape.baseHeight / 4 };
	body = new Rect(pGame, bodyref, config.sighShape.baseHeight, config.sighShape.topWdth / 4);
	head = new circle(pGame, headref, config.sighShape.baseWdth * 1.5);
	leg1 = new Triangle(pGame, leg1ref, ref.x - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3, ref.y + config.sighShape.baseHeight / 2, ref.x - config.sighShape.topWdth / 4, ref.y + config.sighShape.baseHeight / 2, ref.x - config.sighShape.topWdth / 4, ref.y + config.sighShape.baseHeight / 4, config.sighShape.baseHeight / 3);
	leg2 = new Triangle(pGame, leg2ref, 3, 3, 3, 3, 3, 3, config.sighShape.baseHeight / 3);
}
void key::draw() const {
	body->draw();
	head->draw();
	leg1->draw();
	leg2->draw();
}
void key::resizeUp()
{
	point bodyref = RefPoint;
	point headref = { RefPoint.x,RefPoint.y - body->getheight() - body->getwidth() };
	point leg1ref = { RefPoint.x - body->getwidth() ,RefPoint.y - body->getheight() / 4 };
	point leg2ref = { RefPoint.x - body->getwidth() ,RefPoint.y + body->getheight() / 2 };
	body->setRefPoint(bodyref);
	head->setRefPoint(headref);
	leg1->setRefPoint(leg1ref);
	leg2->setRefPoint(leg2ref);
	body->resizeUp();
	head->resizeUp();
	leg1->resizeUp();
	leg2->resizeUp();


}

void key::resizeDown()
{
	point bodyref = RefPoint;
	point headref = { RefPoint.x,RefPoint.y - body->getheight() / 4 - body->getwidth() / 4 };
	point leg1ref = { RefPoint.x - body->getwidth() / 4 ,RefPoint.y - body->getheight() / 4 / 4 };
	point leg2ref = { RefPoint.x - body->getwidth() / 4 ,RefPoint.y + body->getheight() / 2 / 4 };
	body->setRefPoint(bodyref);
	head->setRefPoint(headref);
	leg1->setRefPoint(leg1ref);
	leg2->setRefPoint(leg2ref);
	body->resizeDown();
	head->resizeDown();
	leg1->resizeDown();
	leg2->resizeDown();
}
void key::flip()
{
	int py1 = 300 + config.sighShape.baseHeight / 2;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;
	int spy1 = 3;
	int spy2 = 3;
	int spy3 = 3;
	int temp_spy = spy1;
	spy1 = spy3;
	spy2 = temp_spy;
	spy3 = temp_spy;

	body->flip();
	point headref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 1.2 };
	head = new circle(pGame, headref, config.sighShape.baseWdth * 1.5);
	head->flip();
	point leg1ref = { RefPoint.x - config.sighShape.topWdth / 8,RefPoint.y + config.sighShape.baseHeight / 6 - 33 };
	leg1 = new Triangle(pGame, leg1ref, RefPoint.x - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3, py1, RefPoint.x - config.sighShape.topWdth / 4, py2, RefPoint.x - config.sighShape.topWdth / 4, py3, config.sighShape.baseHeight / 3);
	leg1->flip();
	point leg2ref = { RefPoint.x - config.sighShape.topWdth / 8,RefPoint.y + config.sighShape.baseHeight / 4 };
	leg2 = new Triangle(pGame, leg2ref, 3, spy1, 3, spy2, 3, spy3, config.sighShape.baseHeight / 3);
	leg2->flip();

}
void key::rotate()
{
	point bodyref = RefPoint;
	body = new Rect(pGame, bodyref, config.sighShape.topWdth / 4, config.sighShape.baseHeight);
	body->rotate();

	point headref = { RefPoint.x + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 1.2,RefPoint.y };
	head = new circle(pGame, headref, config.sighShape.baseWdth * 1.5);
	head->rotate();

	point leg1ref = { RefPoint.x + config.sighShape.baseHeight / 6 ,RefPoint.y - config.sighShape.topWdth / 8 - 5 };

	int px1 = 800 - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3;
	int py1 = 300 + config.sighShape.baseHeight / 2;
	int px2 = 800 - config.sighShape.topWdth / 4;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int px3 = 800 - config.sighShape.topWdth / 4;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	leg1 = new Triangle(pGame, leg1ref, px1, py1, px2, py2, px3, py3, config.sighShape.baseHeight / 3);
	leg1->rotate();
	point leg2ref = { RefPoint.x - config.sighShape.baseHeight / 4 , RefPoint.y - config.sighShape.topWdth / 8 - 5 };

	int spx1 = 3;
	int spy1 = 3;
	int spx2 = 3;
	int spy2 = 3;
	int spx3 = 3;
	int spy3 = 3;
	int temp_spx = spx1, temp_spy = spy1;
	spx1 = spx3;
	spy1 = spy3;
	spx3 = spx2;
	spy3 = spy2;
	spx2 = temp_spx;
	spy3 = temp_spy;
	leg2 = new Triangle(pGame, leg2ref, spx1, spy1, spx2, spy2, spx2, spy2, config.sighShape.baseHeight / 3);
	leg2->rotate();

}

pencil::pencil(game* r_pGame, point ref) : shape(r_pGame, ref) {
	point bodyref = ref;
	point tailref = { ref.x, ref.y + config.sighShape.baseHeight / 2 };
	point tipref = { ref.x,ref.y - config.sighShape.baseHeight / 2 - config.sighShape.baseWdth * 0.29 };
	body = new Rect(pGame, bodyref, config.sighShape.baseHeight, config.sighShape.baseWdth);
	tail = new circle(pGame, tailref, config.sighShape.baseWdth / 2);
	tip = new Triangle(pGame, tipref, 3, 3, 3, 3, 3, 3, config.sighShape.baseWdth * 0.29 * 3);
}
void pencil::draw() const {
	body->draw();
	tail->draw();
	tip->draw();

}
void pencil::resizeUp()
{
	point bodyref = RefPoint;
	point tailref = { RefPoint.x, RefPoint.y + body->getheight() };
	point tipref = { RefPoint.x,RefPoint.y - body->getheight() - body->getwidth() };
	body->setRefPoint(bodyref);
	tail->setRefPoint(tailref);
	tip->setRefPoint(tipref);
	body->resizeUp();
	tail->resizeUp();
	tip->resizeUp();
}

void pencil::resizeDown()
{
	point bodyref = RefPoint;
	point tailref = { RefPoint.x, RefPoint.y + body->getheight() / 4 };
	point tipref = { RefPoint.x,RefPoint.y - body->getheight() / 4 - body->getwidth() / 4 };
	body->setRefPoint(bodyref);
	tail->setRefPoint(tailref);
	tip->setRefPoint(tipref);
	body->resizeDown();
	tail->resizeDown();
	tip->resizeDown();
}
void pencil::flip()
{
	body->flip();
	point tailref = { RefPoint.x, RefPoint.y - config.sighShape.baseHeight / 2 };
	tail = new circle(pGame, tailref, config.sighShape.baseWdth / 2);
	tail->flip();

	int py1 = 3;
	int py2 = 3;
	int py3 = 3;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;

	point tipref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 0.29 };
	tip = new Triangle(pGame, tipref, 3, py1, 3, py2, 3, py3, config.sighShape.baseWdth * 0.29 * 3);
	tip->flip();
}
void pencil::rotate()
{
	point bodyref = RefPoint;
	body = new Rect(pGame, bodyref, config.sighShape.baseWdth, config.sighShape.baseHeight);
	body->rotate();

	point tailref = { RefPoint.x - config.sighShape.baseHeight / 2, RefPoint.y };
	tail = new circle(pGame, tailref, config.sighShape.baseWdth / 2);
	tail->rotate();

	point tipref = { RefPoint.x + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 0.29, RefPoint.y };

	int px1 = 3;
	int py1 = 3;
	int px2 = 3;
	int py2 = 3;
	int px3 = 3;
	int py3 = 3;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	tip = new Triangle(pGame, tipref, px1, py1, px2, py2, px3, py3, config.sighShape.baseWdth * 0.29 * 3);
	tip->rotate();
}