#include "game.h"
#include "gameConfig.h"
#include <ctime>


game::game()
{

	//Create the main window
	createWind(config.windWidth, config.windHeight, config.wx, config.wy);
	lvl = 1, score = 0, lives = 5;
	Steps = 0;
	//Create and draw the toolbar
	createToolBar();

	//Create and draw the grid
	createGrid();
	shapesGrid->draw();	//draw the grid and all shapes it contains.

	//Create and clear the status bar
	clearStatusBar();


}

game::~game()
{
	delete pWind;
	delete shapesGrid;
}
/////////////////////////////////////////////////////////////////////////////////////////
//draws the integer 
int game::getLvl() const {
	return lvl;
}

int game::getLives() const {
	return lives;
}

int game::getScore() const {
	return score;
}
void game::setlevel(int level) {
	lvl = level;
	gameToolbar->Del_lvl_liv_score();

}
void game::setlives() {
	lives--;
}
void game::setscore(int s)
{
	score = s;
}
void game::setscore(double x)
{
	score += x;

}
void game::setlives(int l) {
	lives = l;
}
int game::score_equ()
{
	return (givens - Steps) * 2;

}
void game::givensteps()
{
	int totalshapesrandom = (2 * getLvl()) - 1;
	givens = 30 * totalshapesrandom;
	Printsteps();
}
void game::starttimer(int& remainingtime) const {
	time_t starttime = time(0);
	time_t endtime = starttime + countdownduration;
	while (time(0) < endtime) {
		remainingtime = endtime - time(0);
		if (remainingtime <= 0) {

			break;
		}





		for (int i = 0; i < 10000000; i++) {
			for (int j = 0; j < 300; j++) {

			}
		}


	}
}
void game::Printsteps() const
{
	pWind->SetPen(config.bkGrndColor, 1);
	pWind->SetBrush(config.bkGrndColor);
	pWind->DrawRectangle(1000, config.windHeight - (int)(1 * config.statusBarHeight), config.windWidth, 621);

	pWind->SetPen(config.penColor, 50);
	pWind->SetFont(24, BOLD, BY_NAME, "Arial");
	pWind->DrawString(1000, config.windHeight - (int)(0.85 * config.statusBarHeight), "Given Steps = ");
	pWind->DrawInteger(1150, config.windHeight - (int)(0.85 * config.statusBarHeight), givens);
}

void game::GetKey(char K) {
	if (!shapesGrid || !shapesGrid->getActiveShape()) return;

	point x, y, z, m;
	x.x = 30;
	x.y = 0;
	y.x = -30;
	y.y = 0;
	z.x = 0;
	z.y = 30;
	m.x = 0;
	m.y = -30;
	shape* activeShape = shapesGrid->getActiveShape();
	point REF = activeShape->getRef();
	int st;
	int st2;
	int st1;
	int st3;  	
	switch (K) {
	case 8: {
		if (REF.y > 120) {
			activeShape->move(m);
			st = Stepsinc();
			printMessage("steps moved:", st);
		}
		break;
	}
	case 2:
		if (REF.y < 430) {
			activeShape->move(z);
			st1 = Stepsinc();
			printMessage("steps moved:", st1);
		}
		break;
	case 4:
		if (REF.x > 80) {
			activeShape->move(y);
			st2 = Stepsinc();
			printMessage("steps moved:", st2);
		}
		break;
	case 6:
		if (REF.x < 1130) {
			activeShape->move(x);
			st3 = Stepsinc();
			printMessage("steps moved:", st3);
		}
		break;

	case'd':
		shapesGrid->checkMatch();
		gameToolbar->Del_lvl_liv_score();
		break;
	}


	shapesGrid->draw();
}

void game::setlvl(int x)
{
	lvl = x;
}
void game::SelecLvl()
{
	window* pw = getWind();
	int lvl = stoi(getSrting());
	setlvl(lvl);
	//delete previous score,lvl,lives

	gameToolbar->Del_lvl_liv_score();

}
int game::Stepsinc() {
	Steps++;
	return Steps;
}

//////////////////////////////////////////////////////////////////////////////////////////
void game::createWind(int w, int h, int x, int y) 
{
	pWind = new window(w, h, x, y);
	pWind->SetBrush(config.bkGrndColor);
	pWind->SetPen(config.bkGrndColor, 1);
	pWind->DrawRectangle(0, 0, w, h);
}
//////////////////////////////////////////////////////////////////////////////////////////
void game::clearStatusBar() const
{
	//Clear Status bar by drawing a filled rectangle
	pWind->SetPen(config.statusBarColor, 1);
	pWind->SetBrush(config.statusBarColor);
	pWind->DrawRectangle(0, config.windHeight - config.statusBarHeight, config.windWidth, config.windHeight);
}

//////////////////////////////////////////////////////////////////////////////////////////
//Draws the menu (toolbar) in the mode
void game::createToolBar()
{
	gameToolbar = new toolbar(this);
}

void game::createGrid()
{	
	//calc some grid parameters
	point gridUpperLeftPoint = { 0, config.toolBarHeight };
	int gridHeight = config.windHeight - config.toolBarHeight - config.statusBarHeight;
	//create the grid
	shapesGrid = new grid(gridUpperLeftPoint, config.windWidth, gridHeight, this);
}

operation* game::createRequiredOperation(toolbarItem clickedItem)
{
	int st3;
	int st1;
	int st;


	
	operation* op=nullptr;
	switch (clickedItem)
	{
	case ITM_SIGN:
		op = new operAddSign(this);
		printMessage("You Draw a Sign");
		V.push_back(ITM_SIGN);
		break;
	case ITM_Car:
		op = new operAddCar(this);
		printMessage("You Draw a Car");
		V.push_back(ITM_Car);
		break;
	case ITM_tree:
		op = new operAddTree(this);
		printMessage("You Draw a tree");
		V.push_back(ITM_tree);
		break;
	case ITM_lollipop:
		op = new operAddLollipop(this);
		printMessage("You Draw a lollipop");
		V.push_back(ITM_lollipop);
		break;
	case ITM_key:
		op = new operAddkey(this);
		printMessage("You Draw a key");
		V.push_back(ITM_key);
		break;
	case ITM_pencil:
		op = new operAddpencil(this);
		printMessage("You Draw a pencil");
		V.push_back(ITM_pencil);
		break;
	case ITM_robot:
		op = new operAddrobot(this);
		printMessage("You Draw a robot");
		V.push_back(ITM_robot);
		break;
	case ITM_Increase:
		op = new operResizeUp(this);
		
		printMessage("You Increased the shape's size");
		st = Stepsinc();
		Sleep(1000);
		printMessage("steps moved:", st);
		break;
	case ITM_Decrease:
		op = new operResizeDown(this);
		printMessage("You Decreased the shape's size");
		st1 = Stepsinc();
		Sleep(1000);
		printMessage("steps moved:", st1);
		break;
	case ITM_load:
		op = new operLoad(this);
		printMessage("You loaded the window");
		break;
	case ITM_Save:
		op = new operSave(this);
		printMessage("You saved the progress");
		break;
	case ITM_Delete:
		op = new operDeleteShape(this);
		printMessage("You deleted the shape");
		break;
	case ITM_Rotate:
		op = new operRotate(this);
		printMessage("You rotated the shape"); 
		st3 = Stepsinc();
		Sleep(1000);
		printMessage("steps moved:", st3);
		break;
	case ITM_flip:
		op = new operflip(this);
		printMessage("You flipped the shape"); 
		st3 = Stepsinc();
		Sleep(1000);
		printMessage("steps moved:", st3);
		break;
	case ITM_SelectLevel:
		op = new operSelectLevel(this);
		printMessage("Enter level: ");
		

		/*int remainingtime = 0;
		int endtime =  5;
		int counter=0;
		while (counter <= endtime) {
			remainingtime = endtime - counter;
			counter++;
			if (remainingtime < 0) {

				break;
			}




			
			printMessage("Timer:",remainingtime);
			for (int i = 0; i < 10000000; i++) {
				for (int j = 0; j < 300; j++) {

				}
			}


		}*/

		break;



	}
	
	return op;
}

vector<toolbarItem> game::getvector()
{
	return V;
}



//////////////////////////////////////////////////////////////////////////////////////////


void game::printMessage(string msg) const	//Prints a message on status bar
{
	clearStatusBar();	//First clear the status bar

	pWind->SetPen(config.penColor, 50);
	pWind->SetFont(24, BOLD, BY_NAME, "Arial");
	pWind->DrawString(10, config.windHeight - (int)(0.85 * config.statusBarHeight), msg);
}
void game::printMessage(string msg, int msg2) const	//Prints a message on status bar
{
	clearStatusBar();	//First clear the status bar

	pWind->SetPen(config.penColor, 50);
	pWind->SetFont(24, BOLD, BY_NAME, "Arial");
	pWind->DrawString(10, config.windHeight - (int)(0.85 * config.statusBarHeight), msg);
	pWind->DrawInteger(150, config.windHeight - (int)(0.85 * config.statusBarHeight), msg2);
}



window* game::getWind() const		//returns a pointer to the graphics window
{
	return pWind;
}



string game::getSrting() const
{
	string Label;
	char Key;
	keytype ktype;
	pWind->FlushKeyQueue();
	while (1)
	{
		ktype = pWind->WaitKeyPress(Key);
		if (ktype == ESCAPE)	//ESCAPE key is pressed
			return "";	//returns nothing as user has cancelled label
		if (Key == 13)	//ENTER key is pressed
			return Label;
		if (Key == 8)	//BackSpace is pressed
			if (Label.size() > 0)
				Label.resize(Label.size() - 1);
			else
				Key = '\0';
		else
			Label += Key;
		printMessage(Label);
	}
}

grid* game::getGrid() const
{
	// TODO: Add your implementation code here.
	return shapesGrid;
}



////////////////////////////////////////////////////////////////////////
//void game::run() 
//{
//	//This function reads the position where the user clicks to determine the desired operation
//	/*int x, y;*/
//	bool isExit = false;
//
//	//Change the title
//	pWind->ChangeTitle("- - - - - - - - - - SHAPE HUNT (CIE 101 / CIE202 - project) - - - - - - - - - -");
//	toolbarItem clickedItem=ITM_CNT;
//	char k;
//	do
//	{
//		int x, y;
//		//printMessage("Ready...");
//		//1- Get user click
//		/*pWind->WaitMouseClick(x, y)*/;	//Get the coordinates of the user click
//
//		//2-Explain the user click
//		//If user clicks on the Toolbar, ask toolbar which item is clicked
//		while (keytype key = pWind->GetKeyPress(k)) {
//			if (key == ARROW)
//				GetKey(k);
//			pWind->FlushKeyQueue();
//		}
//		if (pWind->GetMouseClick(x, y)) {
//			if (y >= 0 && y < config.toolBarHeight)
//			{
//				clickedItem = gameToolbar->getItemClicked(x);
//
//				//3-create the approp operation accordin to item clicked by the user
//				operation* op = createRequiredOperation(clickedItem);
//				if (op)
//					op->Act();
//				pWind->FlushMouseQueue();
//				//4-Redraw the grid after each action
//				/*if (clickedItem != ITM_Delete)*/
//					shapesGrid->draw();
//
//			}
//		}
//		/*if (pWind->GetMouseClick(x, y)) {
//			if (y >= 0 && y < 60) {
//				clickedItem = gameToolbar->getItemClicked(x);
//				operation* op = createRequiredOperation(clickedItem);
//				if (op)
//
//					op->Act();
//				shapesGrid->draw();
//
//			}
//			pWind->FlushMouseQueue();
//
//			if (clickedItem != ITM_Delete)
//			shapesGrid->draw();
//
//
//		}*/
//
//	} while (clickedItem!=ITM_EXIT);
//}
void game::run()
{
	//This function reads the position where the user clicks to determine the desired operation
	/*int x, y;*/
	bool isExit = false;

	//Change the title
	pWind->ChangeTitle("- - - - - - - - - - SHAPE HUNT (CIE 101 / CIE202 - project) - - - - - - - - - -");
	toolbarItem clickedItem = ITM_CNT;
	char k;
	do
	{
		int x, y;
		//printMessage("Ready...");
		//1- Get user click
		/*pWind->WaitMouseClick(x, y)*/;	//Get the coordinates of the user click

		//2-Explain the user click
		//If user clicks on the Toolbar, ask toolbar which item is clicked
		while (keytype key = pWind->GetKeyPress(k)) {
			if (key == ARROW)
			{
				GetKey(k);
				pWind->FlushKeyQueue();
			}
			else if (key == ASCII) {
				GetKey(k);
				pWind->FlushKeyQueue();
			}

		}
		if (pWind->GetMouseClick(x, y)) {
			if (y >= 0 && y < config.toolBarHeight)
			{
				clickedItem = gameToolbar->getItemClicked(x);

				//3-create the approp operation accordin to item clicked by the user
				operation* op = createRequiredOperation(clickedItem);
				if (op)
					op->Act();
				pWind->FlushMouseQueue();
				//4-Redraw the grid after each action
				/*if (clickedItem != ITM_Delete)*/
				shapesGrid->draw();

			}
		}
		/*if (pWind->GetMouseClick(x, y)) {
			if (y >= 0 && y < 60) {
				clickedItem = gameToolbar->getItemClicked(x);
				operation* op = createRequiredOperation(clickedItem);
				if (op)

					op->Act();
				shapesGrid->draw();

			}
			pWind->FlushMouseQueue();

			if (clickedItem != ITM_Delete)
			shapesGrid->draw();


		}*/

	} while (clickedItem != ITM_EXIT);
}
