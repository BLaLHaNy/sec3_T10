#include "grid.h"
#include "game.h"
#include "gameConfig.h"

#include "ctime"
#include "cstdlib"


grid::grid(point r_uprleft, int wdth, int hght, game* pG)
{
	uprLeft = r_uprleft;
	height = hght;
	width = wdth;
	pGame = pG;
	rows = height / config.gridSpacing;
	cols = width / config.gridSpacing;
	shapeCount = 0;

	for (int i = 0; i < MaxShapeCount; i++)
		shapeList[i] = nullptr;

	activeShape = nullptr;

}

grid::~grid()
{
	for (int i = 0; i < shapeCount; i++)
		delete shapeList[i];
}

void grid::draw() const
{
	clearGridArea();
	window* pWind = pGame->getWind();
	
	pWind->SetPen(config.gridDotsColor,1);
	pWind->SetBrush(config.gridDotsColor);

	//draw dots showing the grid reference points
	for (int r = 1; r < rows; r++)
		for (int c = 0; c < cols; c++)
			pWind->DrawCircle(c * config.gridSpacing, r * config.gridSpacing + uprLeft.y, 1);
			//pWind->DrawPixel(c * config.gridSpacing, r * config.gridSpacing + uprLeft.y);

	//Draw ALL shapes
	for (int i = 0; i < shapeCount; i++)
			if (shapeList[i])
				shapeList[i]->draw();	//draw each shape

	//Draw the active shape
	if(activeShape)
		activeShape->draw();
}

void grid::clearGridArea() const
{
	window* pWind = pGame->getWind();	
	pWind->SetPen(config.bkGrndColor, 1);
	pWind->SetBrush(config.bkGrndColor);
	pWind->DrawRectangle(uprLeft.x, uprLeft.y, uprLeft.x + width, uprLeft.y + height);
}

//Adds a shape to the randomly created shapes list.
bool grid::addShape(shape* newShape)
{
	//TODO:
	// 1- Check that the shape can be drawn witout being clipped by grid boundaries
	// 2- check shape count doesn't exceed maximum count
	// return false if any of the checks fail
	
	//Here we assume that the above checks are passed
	shapeList[shapeCount++] = newShape;
	return true;
}

void grid::setActiveShape(shape* actShape)
{
	activeShape = actShape;
}

void grid::Delete() 
{
	if (activeShape)
	{
		delete activeShape;
		activeShape = nullptr;
	}
}
point grid::randompoint()
{

	point refy;
	if (pGame->getLvl() < 3)
	{
		int xrand;
		int yrand;
		xrand = 100 + rand() % 336;
		refy.x = xrand - xrand % 30;
		yrand = config.toolBarHeight + 120 + rand() % 181;
		refy.y = yrand - yrand % 30;
		return refy;
	}
	else
	{

		int xrand;
		int yrand;
		xrand = 200 + rand() % 201;
		refy.x = xrand - xrand % 30;
		yrand = config.toolBarHeight + 150 + rand() % 181;
		refy.y = yrand - yrand % 30;

		return refy;
	}
}
color grid::getcolor(int c)
{
	switch (c) {
	case  0:
		return BLACK;
	case 1:
		return BLUE;
	case 2:
		return VIOLET;
	case 3:
		return BROWN;
	case 4:
		return GREENYELLOW;
	case 5:
		return RED;
	}
}
void grid::deleteactive()
{
	if (activeShape)
	{
		delete activeShape;
		activeShape = nullptr;
	}
}
void grid::randomshapes()
{
	time_t* s = 0;
	srand(time(s));
	window* pw = pGame->getWind();
	int sizeofarray = (2 * pGame->getLvl()) - 1;
	for (int i = 0; i < sizeofarray; i++) {
		int randnumb = rand() % 7;
		int randcolor = rand() % 6;
		color c = getcolor(randcolor);
		if (pGame->getLvl() >= 3)
		{
			c = BLACK;
		}

		shape* randomizedshapes = nullptr;
		switch (randnumb) {
		case(0): {
			randomizedshapes = new Sign(pGame, randompoint(), config.sighShape.topHeight, config.sighShape.topWdth, config.sighShape.baseHeight, config.sighShape.baseWdth,c);
			break;
		}
		case(1): {
			randomizedshapes = new Lollipop(pGame, randompoint(), config.sighShape.baseHeight * 1.5, config.sighShape.baseWdth, config.sighShape.topWdth * 3 / 8,c);
			break;
		}
		case(2): {
			randomizedshapes = new key(pGame, randompoint(), config.sighShape.baseHeight, config.sighShape.topWdth / 4, config.sighShape.baseWdth * 1.5, config.sighShape.baseHeight / 3, config.sighShape.baseHeight / 3, c);
			break;
		}
		case(3): {
			randomizedshapes = new Tree(pGame, randompoint(), config.sighShape.baseHeight, config.sighShape.topWdth / 4, config.sighShape.baseHeight * 3 / 4,c);
			break;
		}
		case(4): {
			randomizedshapes = new robot(pGame, randompoint(), config.sighShape.baseHeight, config.sighShape.topWdth / 2, config.sighShape.topWdth / 4, config.sighShape.baseHeight / 1.5,c);
			break;
		}
		case(5): {
			randomizedshapes = new Car(pGame, randompoint(), config.sighShape.topHeight, config.sighShape.topWdth, 1.2 * config.sighShape.baseWdth, 1.2 * config.sighShape.baseWdth, config.sighShape.topWdth / 2.5,c);
			break;
		}
		case(6): {
			randomizedshapes = new pencil(pGame, randompoint(), config.sighShape.baseHeight, config.sighShape.baseWdth, config.sighShape.baseWdth / 2, config.sighShape.baseWdth * 0.29 * 3,c);
			break;
		}
		}
		int randswitch = rand() % 4;
		int randresize = rand() % 1;
		int k;
		switch (randswitch)
		{
		case(0): {
			for (k = 0; k < randresize; k++) {
				randomizedshapes->resizeUp();
				randomizedshapes->rotate();
			}
			break;
		}
		case(1): {
			for (k = 0; k < randresize; k++) {
				randomizedshapes->resizeUp();

			}
			break;
		}
		case(2): {
			for (k = 0; k < randresize; k++) {
				randomizedshapes->resizeDown();
			}
			break;
		}
		case(3): {
			for (k = 0; k < randresize; k++) {
				randomizedshapes->resizeDown();
				randomizedshapes->rotate();

			}
			break;
		}
		default:
			break;
		}
		addShape(randomizedshapes);
		s += 5;
	}
}
//void grid::checkMatch()
//{
//	for (int i = 0; i < pGame->getLvl() * 2 - 1; i++) {
//		if (activeShape && shapeList[i]) {
//			if (activeShape->match(shapeList[i])) {
//				delete activeShape;
//				delete shapeList[i];
//				activeShape = nullptr;
//				shapeList[i] = nullptr;
//				pGame->setscore(2.0);
//			}
//			else {
//				delete activeShape;
//				activeShape = nullptr;
//				pGame->setscore(-1.0);
//
//			}
//		}
//	}
//}
void grid::checkMatch()
{
	for (int i = 0; i < pGame->getLvl() * 2 - 1; i++) {
		if (activeShape && shapeList[i]) {
			if (activeShape->match(shapeList[i])) {
				delete activeShape;
				delete shapeList[i];
				activeShape = nullptr;
				shapeList[i] = nullptr;
				pGame->setscore(2.0);
			}
			else {
				delete activeShape;
				activeShape = nullptr;
				pGame->setscore(-1.0);
			}
			break; // Exit the loop after processing the match
		}
	}
}
