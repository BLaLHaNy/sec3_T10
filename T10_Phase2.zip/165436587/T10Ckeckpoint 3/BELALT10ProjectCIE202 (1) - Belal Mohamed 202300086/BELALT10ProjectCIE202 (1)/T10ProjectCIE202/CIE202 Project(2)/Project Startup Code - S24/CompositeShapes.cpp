#include "CompositeShapes.h"
#include "gameConfig.h"
#include <fstream>
#include <iostream>

using namespace std;


////////////////////////////////////////////////////  class Sign  ///////////////////////////////////////
Sign::Sign(game* r_pGame, point ref, int th, int tw, int bh, int bw,color FC):shape(r_pGame, ref)
{
	fillColor = FC;
	//calc the ref point of the Sign base and top rectangles relative to the Sign shape
	point topRef = ref;	//top rect ref is the same as the sign
	point baseRef = { ref.x, ref.y + th / 2  + bh / 2  };
	top = new Rect(pGame, topRef, th, tw ,fillColor);
	base = new Rect(pGame, baseRef, bh, bw,fillColor);
}

void Sign::draw() const
{
	base->draw();
	top->draw();
}
void Sign::resizeUp()
{
	point topRef = RefPoint;
	point baseRef = { RefPoint.x,RefPoint.y + (base->getheight() + top->getheight()) };
	base->setRefPoint(baseRef);
	top->setRefPoint(topRef);
	top->resizeUp();
	base->resizeUp();
	numre++;
}
void Sign::resizeDown()
{
	point topRef = RefPoint;
	point baseRef = { RefPoint.x,RefPoint.y + (base->getheight() / 4 + top->getheight() / 4) };
	base->setRefPoint(baseRef);
	top->setRefPoint(topRef);
	top->resizeDown();
	base->resizeDown();
	numre--;
}
void Sign::flip()
{

	top->flip();
	point baseRef = { RefPoint.x, RefPoint.y - config.sighShape.topHeight / 2 - config.sighShape.baseHeight / 2 };
	base = new Rect(pGame, baseRef, config.sighShape.baseHeight, config.sighShape.baseWdth,fillColor);
	base->flip();
}
void Sign::rotate()
{
	point topRef = RefPoint;
	top = new Rect(pGame, topRef, config.sighShape.topWdth, config.sighShape.topHeight, fillColor);
	top->rotate();
	point baseRef = { RefPoint.x - config.sighShape.topHeight / 2 - config.sighShape.baseHeight / 2, RefPoint.y };
	base = new Rect(pGame, baseRef, config.sighShape.baseWdth, config.sighShape.baseHeight, fillColor);
	base->rotate();
	numro++;
}
void Sign::move(point p) {
	top->move(p);
	base->move(p);
	this->setRefPoint(top->getRef());
}
void Sign::Save()
{

	ofstream progress("Progress1.txt");
	progress << "\n" << "\n" << "\n" << "\n" << "\n" << "\n";
	progress << RefPoint.x << "\n" << RefPoint.y << "\n";				// Line 5 -> x Ref point , Line 6 -> y Ref Point
	progress << top->getheight() << "\n" << top->getwidth() << "\n";	// Line 7 -> top height , Line 8 -> top width
	progress << base->getheight() << "\n" << base->getwidth() << "\n";	// Line 9 -> base height , Line 10 -> base width
	progress.close();

}

void Sign::Load()
{
	/*cout << "here\n";
	int  Theight = 0, Twidth = 0, Bheight = 0, Bwidth = 0;

	ifstream progress("Progress1.txt");
	for (int i = 0; i < 10; ++i) 
	{

		if (i >= 6) {
			progress >> Theight >> Twidth >> Bheight >> Bwidth;
		}
	}
	top->setheight(Theight);
	top->setwidth(Twidth);
	base->setheight(Bheight);
	base->setwidth(Bwidth);
	progress.close();*/
}
bool Sign::match(shape* other) const {

	Sign* otherSign = dynamic_cast<Sign*>(other);

	if (otherSign) {
		return (this->numre == other->getnumre() && this->numro == other->getnumro() && this->RefPoint.x == other->getRef().x && this->RefPoint.y == other->getRef().y);
	}

	return false;
}


////////////////////////////////////////////////////  class House  ///////////////////////////////////////

House::House(game* r_pGame, point ref,color FC) :shape(r_pGame, ref) {
	fillColor = FC;
	point frontref = ref;
	point roofref = { ref.x, ref.y - config.sighShape.topHeight * 1.5  - config.sighShape.baseWdth +20 };
	point windowref = { ref.x,ref.y - config.sighShape.topHeight * 1.5 / 2 - config.sighShape.baseWdth / 3 };
	front = new Rect(pGame, frontref, config.sighShape.topHeight * 1.5, config.sighShape.topWdth*0.8, fillColor);
	roof = new Triangle(pGame, roofref, ref.x, ref.y - config.sighShape.topHeight * 3/4 - 3 * config.sighShape.baseWdth, ref.x - config.sighShape.topWdth / 2-3 * config.sighShape.baseWdth, ref.y - config.sighShape.topHeight * 1.5 / 2, ref.x + config.sighShape.topWdth / 2, ref.y - config.sighShape.topHeight * 1.5 / 2, 0.86*config.sighShape.topWdth, fillColor);
	window = new circle(pGame, windowref, config.sighShape.topHeight/2.5, fillColor);
}
void House::draw() const {
	front->draw();
	roof->draw();
	window->draw();
}
void House::resizeUp()
{

}
void House::resizeDown()
{

}
void House::rotate()
{

}
void House::flip()
{

}

void House::Save()
{
}

void House::Load()
{
}
void House::move(point p) {

}
bool House::match(shape* other) const {
	return false;
}

////////////////////////////////////////////////////  class Car  ///////////////////////////////////////

Car::Car(game* r_pGame, point ref, int BDheight,int BDwidth,int BWrad,int FWrad,int FBside,color FC) :shape(r_pGame, ref) {

	/*BDwidth = config.sighShape.topWdth;
	BDheight = config.sighShape.topHeight;
	BWrad = 1.2 * config.sighShape.baseWdth;
	FWrad = 1.2 * config.sighShape.baseWdth;
	FBside = config.sighShape.topWdth / 2.5;*/
	fillColor = FC;
	point bodyref = ref;
	point backwheelref = { ref.x - BDwidth / 2 + BWrad,ref.y + BDheight / 2 + BWrad };
	point frontwheelref = { ref.x + BDwidth / 2 - BWrad,ref.y + BDheight / 2 + BWrad };
	point frontbodyref = { ref.x+ BDwidth /2,ref.y };
	body = new Rect(pGame, bodyref, BDheight, BDwidth,fillColor);
	backwheel = new circle(pGame, backwheelref, BWrad, fillColor);
	frontwheel = new circle(pGame, frontwheelref, FWrad, fillColor);
	frontbody = new Triangle(pGame, frontbodyref, 3, 3, 3, 3, 3, 3, FBside, fillColor);
	
}

void Car::draw() const {
	frontwheel->draw();
	body->draw();
	backwheel->draw();
	frontbody->draw();
}
void Car::resizeUp()
{
	point bodyref = RefPoint;
	point backwheelref = { RefPoint.x - body->getwidth() + 0.5 * body->getwidth(),RefPoint.y + body->getheight() + 0.5 * body->getwidth() };
	point frontwheelref = { RefPoint.x + body->getwidth() - 0.5 * body->getwidth(),RefPoint.y + body->getheight() + 0.5 * body->getwidth() };
	point frontbodyref = { RefPoint.x + body->getwidth(),RefPoint.y };
	frontwheel->setRefPoint(frontwheelref);
	body->setRefPoint(bodyref);
	backwheel->setRefPoint(backwheelref);
	frontbody->setRefPoint(frontbodyref);
	frontwheel->resizeUp();
	body->resizeUp();
	backwheel->resizeUp();
	frontbody->resizeUp();
	numre++;

}
void Car::resizeDown()
{
	point bodyref = RefPoint;
	point backwheelref = { RefPoint.x - body->getwidth() / 4 + 0.5 * body->getwidth() / 4,RefPoint.y + body->getheight() / 4 + 0.5 * body->getwidth() / 4 };
	point frontwheelref = { RefPoint.x + body->getwidth() / 4 - 0.5 * body->getwidth() / 4,RefPoint.y + body->getheight() / 4 + 0.5 * body->getwidth() / 4 };
	point frontbodyref = { RefPoint.x + body->getwidth() / 4,RefPoint.y };
	frontwheel->setRefPoint(frontwheelref);
	body->setRefPoint(bodyref);
	backwheel->setRefPoint(backwheelref);
	frontbody->setRefPoint(frontbodyref);
	frontwheel->resizeDown();
	body->resizeDown();
	backwheel->resizeDown();
	frontbody->resizeDown();
	numre--;
}
void Car::flip()
{


	point backwheelref = { RefPoint.x - config.sighShape.topWdth / 2 + 1.2 * config.sighShape.baseWdth,RefPoint.y - config.sighShape.topHeight / 2 - 1.2 * config.sighShape.baseWdth };


	point frontwheelref = { RefPoint.x + config.sighShape.topWdth / 2 - 1.2 * config.sighShape.baseWdth,RefPoint.y - config.sighShape.topHeight / 2 - 1.2 * config.sighShape.baseWdth };


	int py1 = 3;
	int py2 = 3;
	int py3 = 3;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;

	point frontbodyref = { RefPoint.x + config.sighShape.topWdth / 2,RefPoint.y };
	frontbody = new Triangle(pGame, frontbodyref, 3, py1, 3, py2, 3, py3, 40, fillColor);
	backwheel = new circle(pGame, backwheelref, 1.2 * config.sighShape.baseWdth, fillColor);
	frontwheel = new circle(pGame, frontwheelref, 1.2 * config.sighShape.baseWdth, fillColor);
	frontbody->flip();
	body->flip();
	backwheel->flip();
	frontwheel->flip();

}

void Car::Save()
{
	ofstream progress("Progress1.txt");
	progress << "\n" << "\n" << "\n" << "\n" << "\n" << "\n";
	progress << RefPoint.x << "\n" << RefPoint.y << "\n";							// Line 5 -> x Ref point , Line 6 -> y Ref Point
	progress << body->getheight() << "\n" << body->getwidth() << "\n";				// Line 7 -> body height , Line 8 -> body width
	progress << backwheel->getradius() << "\n" << frontwheel->getradius() << "\n";	// Line 9 -> backwheel rad , Line 10 -> frontwheel rad
	progress << frontbody->getside() << "\n";										// Line 11 -> front body side
	progress.close();
}

void Car::Load()
{
}
void Car::move(point p) {
	body->move(p);
	frontbody->move(p);
	frontwheel->move(p);
	backwheel->move(p);
	this->setRefPoint(body->getRef());
}

void Car::rotate()
{

	body->rotate();
	

	point backwheelref = { RefPoint.x - config.sighShape.topWdth / 2 - 1.2 * config.sighShape.baseWdth,RefPoint.y - config.sighShape.topHeight / 2 + 1.2 * config.sighShape.baseWdth };
	backwheel = new circle(pGame, backwheelref, 1.2 * config.sighShape.baseWdth, fillColor);
	backwheel->rotate();

	point frontwheelref = { RefPoint.x - config.sighShape.topWdth / 2 - 1.2 * config.sighShape.baseWdth,RefPoint.y + config.sighShape.topHeight / 2 - 1.2 * config.sighShape.baseWdth };

	frontwheel->rotate();

	point frontbodyref = { RefPoint.x ,RefPoint.y + config.sighShape.topWdth / 2 };
	int px1 = 3;
	int px2 = 3;
	int px3 = 3;
	int py1 = 3;
	int py2 = 3;
	int py3 = 3;
	int temp_x = px1, temp_y = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_x;
	py2 = temp_y;
	frontbody = new Triangle(pGame, frontbodyref, px1, py1, px2, py2, px3, py3, config.sighShape.topWdth / 2.5, fillColor);
	frontbody->rotate();
	numro++;
}
bool Car::match(shape* other) const {
	const Car* otherCar = dynamic_cast<const Car*>(other);

	if (otherCar) {
		return (this->numre == other->getnumre() && this->numro == other->getnumro() && this->RefPoint.x == other->getRef().x && this->RefPoint.y == other->getRef().y);
	}
	return false;
}

////////////////////////////////////////////////////  class Lollipop  ///////////////////////////////////////

Lollipop::Lollipop(game* r_pGame, point ref, int Sheight, int Swidth, int Crad,color FC) : shape(r_pGame, ref) {

	/*Sheight = config.sighShape.baseHeight * 1.5
	Swidth = config.sighShape.baseWdth
	Crad = config.sighShape.topWdth * 3 / 8*/
	fillColor = FC;
	point stickref = ref;
	point candyref = { ref.x,ref.y - Sheight / 2 };
	stick = new Rect(pGame, stickref, Sheight, Swidth, fillColor);
	candy = new circle(pGame, candyref, Crad, fillColor);
}
void Lollipop::draw() const {
	stick->draw();
	candy->draw();
}
void Lollipop::move(point p) {
	stick->move(p);
	candy->move(p);
	this->setRefPoint(stick->getRef());
}

void Lollipop::resizeUp()
{
	point stickref = RefPoint;
	point candyref = { RefPoint.x,RefPoint.y - stick->getheight() };
	stick->setRefPoint(stickref);
	candy->setRefPoint(candyref);
	stick->resizeUp();
	candy->resizeUp();
	numre++;
}

void Lollipop::resizeDown()
{
	point stickref = RefPoint;
	point candyref = { RefPoint.x,RefPoint.y - stick->getheight() / 4 };
	stick->setRefPoint(stickref);
	candy->setRefPoint(candyref);
	stick->resizeDown();
	candy->resizeDown();
	numre--;
}

void Lollipop::flip()
{

	stick->flip();
	point candyref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 };
	candy = new circle(pGame, candyref, config.sighShape.topWdth * 3 / 8, fillColor);
	candy->flip();



}

void Lollipop::Save()
{
	ofstream progress("Progress1.txt");
	progress << "\n" << "\n" << "\n" << "\n" << "\n" << "\n";
	progress << RefPoint.x << "\n" << RefPoint.y << "\n";							// Line 5 -> x Ref point , Line 6 -> y Ref Point
	progress << stick->getheight() << "\n" << stick->getwidth() << "\n";			// Line 7 -> stick height , Line 8 -> stick width
	progress << candy->getradius() << "\n";											// Line 9 -> candy radius; 
	progress.close();
}
void Lollipop::Load()
{

}
void Lollipop::rotate() {
	point stickref = RefPoint;



	stick = new Rect(pGame, stickref, config.sighShape.baseWdth * 1.5, config.sighShape.baseHeight, fillColor);
	stick->rotate();


	point candyref = { RefPoint.x + config.sighShape.baseHeight / 2 + 25, RefPoint.y };
	candy = new circle(pGame, candyref, config.sighShape.topWdth * 3 / 8, fillColor);
	candy->rotate();
	numro++;
}
bool Lollipop::match(shape* other) const {
	const Lollipop* otherLollipop = dynamic_cast<const Lollipop*>(other);

	if (otherLollipop) {
		return (this->numre == other->getnumre() && this->numro == other->getnumro() && this->RefPoint.x == other->getRef().x && this->RefPoint.y == other->getRef().y);
	}
	return false;
}
////////////////////////////////////////////////////  class Tree  ///////////////////////////////////////

Tree::Tree(game* r_pGame, point ref, int Barkheight, int Barkwidth, int Leafside,color FC) : shape(r_pGame, ref) {

	//Barkheight= config.sighShape.baseHeight
	//Barkwidth= config.sighShape.topWdth / 4
	//Leafside= config.sighShape.baseHeight * 3 / 4

	/*config.sighShape.topWdth * 1.5 = Barkwidth *6*/
	fillColor = FC;
	point barkref = ref;
	point leafref = { ref.x,ref.y - Barkheight / 2 };
	bark = new Rect(pGame, barkref, Barkheight, Barkwidth, fillColor);
	leaf = new Triangle(pGame, leafref, ref.x, ref.y - Leafside, ref.x - Barkwidth * 6, ref.y, ref.x + Barkwidth * 6, ref.y, Leafside, fillColor);
}
void Tree::draw() const {
	bark->draw();
	leaf->draw();
}
void Tree::move(point p) {
	bark->move(p);
	leaf->move(p);
	this->setRefPoint(bark->getRef());
}

void Tree::resizeUp()
{
	point barkref = RefPoint;
	point leafref = { RefPoint.x,RefPoint.y - bark->getheight() };
	bark->setRefPoint(barkref);
	leaf->setRefPoint(leafref);
	bark->resizeUp();
	leaf->resizeUp();
	numre++;
}

void Tree::resizeDown()
{
	point barkref = RefPoint;
	point leafref = { RefPoint.x,RefPoint.y - bark->getheight() / 4 };
	bark->setRefPoint(barkref);
	leaf->setRefPoint(leafref);
	bark->resizeDown();
	leaf->resizeDown();
	numre--;
}
void Tree::flip()
{

	bark->flip();
	point leafref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 };


	int py1 = 300 - config.sighShape.baseHeight * 3 / 4;
	int py2 = 300;
	int py3 = 300;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;

	leaf = new Triangle(pGame, leafref, RefPoint.x, py1, RefPoint.x - config.sighShape.topWdth * 1.5, py2, RefPoint.x + config.sighShape.topWdth * 1.5, py3, config.sighShape.baseHeight * 3 / 4, fillColor);
	leaf->flip();

}
void Tree::Save()
{
	ofstream progress("Progress1.txt");
	progress << "\n" << "\n" << "\n" << "\n" << "\n" << "\n";
	progress << RefPoint.x << "\n" << RefPoint.y << "\n";							// Line 5 -> x Ref point , Line 6 -> y Ref Point
	progress << bark->getheight() << "\n" << bark->getwidth() << "\n";				// Line 7 -> bark height , Line 8 -> bark width
	progress << leaf->getside() << "\n";											// Line 9 -> leaf side; 
	progress.close();
}
void Tree::Load()
{

}

void Tree::rotate() {

	point barkref = RefPoint;
	bark = new Rect(pGame, barkref, config.sighShape.topWdth / 4, config.sighShape.baseHeight, fillColor);
	bark->rotate();

	point leafref = { RefPoint.x + config.sighShape.baseHeight / 2,RefPoint.y };
	int px1 = 800;
	int py1 = 300 - config.sighShape.baseHeight * 3 / 4;
	int px2 = 800 - config.sighShape.topWdth * 1.5;
	int py2 = 300;
	int px3 = 800 + config.sighShape.topWdth * 1.5;
	int py3 = 300;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	leaf = new Triangle(pGame, leafref, px1, py1, px2, py2, px3, py3, config.sighShape.baseHeight * 3 / 4, fillColor);
	leaf->rotate();
	numro++;
}
bool Tree::match(shape* other) const {
	const Tree* otherTree = dynamic_cast<const Tree*>(other);

	if (otherTree) {
		return (this->numre == other->getnumre() && this->numro == other->getnumro() && this->RefPoint.x == other->getRef().x && this->RefPoint.y == other->getRef().y);
	}
	return false;
}




////////////////////////////////////////////////////  class robot  ///////////////////////////////////////

robot::robot(game* r_pGame, point ref, int RobotBodyHeight, int RobotBodyWidth, int RobotHeadrad, int RobotLegside, color FC) : shape(r_pGame, ref) {

	//RobotBodyHeight= config.sighShape.baseHeight
	//RobotBodyWidth= config.sighShape.topWdth / 2
	//RobotHeadrad= config.sighShape.topWdth / 4
	//RobotLegside= config.sighShape.baseHeight / 1.5

	/*config.sighShape.baseWdth * 3 = 60*/
	fillColor = FC;
	point bodyref = ref;
	point headref = { ref.x,ref.y - RobotBodyHeight / 2 - RobotHeadrad };
	point legref = { ref.x ,ref.y + RobotBodyHeight / 4 +20 };
	body = new Rect(pGame, bodyref, RobotBodyHeight, RobotBodyWidth, fillColor);
	head = new circle(pGame, headref, RobotHeadrad, fillColor);
	leg = new Triangle(pGame, legref, ref.x - RobotHeadrad - 60, ref.y + RobotBodyHeight / 2, ref.x - RobotHeadrad, ref.y + RobotBodyHeight / 2, ref.x - RobotHeadrad, ref.y + RobotBodyHeight / 4, RobotLegside, fillColor);

}
void robot::draw() const {
	body->draw();
	head->draw();
	leg->draw();
}
void robot::move(point p) {
	body->move(p);
	head->move(p);
	leg->move(p);
	this->setRefPoint(body->getRef());
}

void robot::resizeUp()
{
	point bodyref = RefPoint;
	point headref = { RefPoint.x,RefPoint.y - body->getheight() - body->getwidth() };
	point legref = { RefPoint.x, RefPoint.y + body->getheight() };
	body->setRefPoint(bodyref);
	head->setRefPoint(headref);
	leg->setRefPoint(legref);
	body->resizeUp();
	head->resizeUp();
	leg->resizeUp();
	numre++;
}

void robot::resizeDown()
{
	point bodyref = RefPoint;
	point headref = { RefPoint.x,RefPoint.y - body->getheight() / 4 - body->getwidth() / 4 };
	point legref = { RefPoint.x, RefPoint.y + body->getheight() / 4 };
	body->setRefPoint(bodyref);
	head->setRefPoint(headref);
	leg->setRefPoint(legref);
	body->resizeDown();
	head->resizeDown();
	leg->resizeDown();
	numre--;
}

void robot::flip()
{
	body->flip();
	point headref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 + config.sighShape.topWdth / 4 };
	head = new circle(pGame, headref, config.sighShape.topWdth / 4, fillColor);
	point legref = { RefPoint.x ,RefPoint.y - config.sighShape.baseHeight / 4 - 20 };
	int py1 = 300 + config.sighShape.baseHeight / 2;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;
	leg = new Triangle(pGame, legref, RefPoint.x - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3, py1, RefPoint.x - config.sighShape.topWdth / 4, py2, RefPoint.x - config.sighShape.topWdth / 4, py3, config.sighShape.baseHeight / 1.5, fillColor);
	leg->flip();
}

void robot::Save()
{
	ofstream progress("Progress1.txt");
	progress << "\n" << "\n" << "\n" << "\n" << "\n" << "\n";
	progress << RefPoint.x << "\n" << RefPoint.y << "\n";							// Line 5 -> x Ref point , Line 6 -> y Ref Point
	progress << body->getheight() << "\n" << body->getwidth() << "\n";				// Line 7 -> body height , Line 8 -> body width
	progress << head->getradius() << "\n" << leg->getside() << "\n";				// Line 9 -> head radius , Line 10 -> leg side
	progress.close();
}

void robot::Load()
{

}

void robot::rotate()
{
	point bodyref = RefPoint;
	body = new Rect(pGame, bodyref, config.sighShape.topWdth / 2, config.sighShape.baseHeight, fillColor);
	body->rotate();

	point headref = { RefPoint.x - config.sighShape.baseHeight / 2 - config.sighShape.topWdth / 4 ,RefPoint.y };
	head = new circle(pGame, headref, config.sighShape.topWdth / 4, fillColor);
	head->rotate();

	point legref = { RefPoint.x + config.sighShape.baseHeight / 4 + 25,RefPoint.y };
	int px1 = 800 - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3;
	int py1 = 300 + config.sighShape.baseHeight / 2;
	int px2 = 800 - config.sighShape.topWdth / 4;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int px3 = 800 - config.sighShape.topWdth / 4;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	leg = new Triangle(pGame, legref, px1, py1, px2, py2, px3, py3, config.sighShape.baseHeight / 1.5, fillColor);
	leg->rotate();
	numro++;

}
bool robot::match(shape* other) const {
	const robot* otherrobot = dynamic_cast<const robot*>(other);

	if (otherrobot) {
		return (this->numre == other->getnumre() && this->numro == other->getnumro() && this->RefPoint.x == other->getRef().x && this->RefPoint.y == other->getRef().y);
	}
	return false;
}


key::key(game* r_pGame, point ref,int KBodyHeight, int KBodyWidth, int KHeadrad, int KLeg1side, int KLeg2side, color FC) : shape(r_pGame, ref) {

	/*KBodyHeight= config.sighShape.baseHeight
	KBodyWidth= config.sighShape.topWdth / 4
	KHeadrad = config.sighShape.baseWdth * 1.5
	KLeg1side = config.sighShape.baseHeight / 3
	KLeg2side= config.sighShape.baseHeight / 3*/

	/*config.sighShape.baseWdth * 1.2= KHeadrad*0.8
	config.sighShape.baseWdth * 3= KHeadrad*2
	config.sighShape.topWdth / 8 = KBodyWidth/2*/
	fillColor = FC;
	point bodyref = ref;
	point headref = { ref.x,ref.y - KBodyHeight / 2 - KHeadrad * 0.8 };
	point leg1ref = { ref.x - KBodyWidth / 2,ref.y - KBodyHeight / 6 };
	point leg2ref = { ref.x - KBodyWidth / 2,ref.y + KBodyHeight / 4 };
	body = new Rect(pGame, bodyref, KBodyHeight, KBodyWidth, fillColor);
	head = new circle(pGame, headref, KHeadrad, fillColor);
	leg1 = new Triangle(pGame, leg1ref, ref.x - KBodyWidth - KHeadrad * 2, ref.y + KBodyHeight / 2, ref.x - KBodyWidth, ref.y + KBodyHeight / 2, ref.x - KBodyWidth, ref.y + KBodyHeight / 4, KLeg1side, fillColor);
	leg2 = new Triangle(pGame, leg2ref, 3, 3, 3, 3, 3, 3, KLeg2side, fillColor);
}
void key::draw() const {
	body->draw();
	head->draw();
	leg1->draw();
	leg2->draw();
}
void key::move(point p) {
	body->move(p);
	head->move(p);
	leg1->move(p);
	leg2->move(p);
	this->setRefPoint(body->getRef());
}
void key::resizeUp()
{
	point bodyref = RefPoint;
	point headref = { RefPoint.x,RefPoint.y - body->getheight() - body->getwidth() };
	point leg1ref = { RefPoint.x - body->getwidth() ,RefPoint.y - body->getheight() / 4 };
	point leg2ref = { RefPoint.x - body->getwidth() ,RefPoint.y + body->getheight() / 2 };
	body->setRefPoint(bodyref);
	head->setRefPoint(headref);
	leg1->setRefPoint(leg1ref);
	leg2->setRefPoint(leg2ref);
	body->resizeUp();
	head->resizeUp();
	leg1->resizeUp();
	leg2->resizeUp();
	numre++;

}

void key::resizeDown()
{
	point bodyref = RefPoint;
	point headref = { RefPoint.x,RefPoint.y - body->getheight() / 4 - body->getwidth() / 4 };
	point leg1ref = { RefPoint.x - body->getwidth() / 4 ,RefPoint.y - body->getheight() / 4 / 4 };
	point leg2ref = { RefPoint.x - body->getwidth() / 4 ,RefPoint.y + body->getheight() / 2 / 4 };
	body->setRefPoint(bodyref);
	head->setRefPoint(headref);
	leg1->setRefPoint(leg1ref);
	leg2->setRefPoint(leg2ref);
	body->resizeDown();
	head->resizeDown();
	leg1->resizeDown();
	leg2->resizeDown();
	numre--;
}
void key::flip()
{
	int py1 = 300 + config.sighShape.baseHeight / 2;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;
	int spy1 = 3;
	int spy2 = 3;
	int spy3 = 3;
	int temp_spy = spy1;
	spy1 = spy3;
	spy2 = temp_spy;
	spy3 = temp_spy;

	body->flip();
	point headref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 1.2 };
	head = new circle(pGame, headref, config.sighShape.baseWdth * 1.5, fillColor);
	head->flip();
	point leg1ref = { RefPoint.x - config.sighShape.topWdth / 8,RefPoint.y + config.sighShape.baseHeight / 6 - 33 };
	leg1 = new Triangle(pGame, leg1ref, RefPoint.x - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3, py1, RefPoint.x - config.sighShape.topWdth / 4, py2, RefPoint.x - config.sighShape.topWdth / 4, py3, config.sighShape.baseHeight / 3, fillColor);
	leg1->flip();
	point leg2ref = { RefPoint.x - config.sighShape.topWdth / 8,RefPoint.y + config.sighShape.baseHeight / 4 };
	leg2 = new Triangle(pGame, leg2ref, 3, spy1, 3, spy2, 3, spy3, config.sighShape.baseHeight / 3, fillColor);
	leg2->flip();

}
void key::Save()
{
	ofstream progress("Progress1.txt");
	progress << "\n" << "\n" << "\n" << "\n" << "\n" << "\n";
	progress << RefPoint.x << "\n" << RefPoint.y << "\n";							// Line 5 -> x Ref point , Line 6 -> y Ref Point
	progress << body->getheight() << "\n" << body->getwidth() << "\n";				// Line 7 -> body height , Line 8 -> body width
	progress << head->getradius() << "\n" << leg1->getside() << "\n";				// Line 9 -> head radius , Line 10 -> leg1 side
	progress << leg2->getside() << "\n";											// Line 11 -> leg2 radius 
	progress.close();
}
void key::Load()
{

}
void key::rotate()
{
	point bodyref = RefPoint;
	body = new Rect(pGame, bodyref, config.sighShape.topWdth / 4, config.sighShape.baseHeight, fillColor);
	body->rotate();

	point headref = { RefPoint.x + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 1.2,RefPoint.y };
	head = new circle(pGame, headref, config.sighShape.baseWdth * 1.5, fillColor);
	head->rotate();

	point leg1ref = { RefPoint.x + config.sighShape.baseHeight / 6 ,RefPoint.y - config.sighShape.topWdth / 8 - 5 };

	int px1 = 800 - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3;
	int py1 = 300 + config.sighShape.baseHeight / 2;
	int px2 = 800 - config.sighShape.topWdth / 4;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int px3 = 800 - config.sighShape.topWdth / 4;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	leg1 = new Triangle(pGame, leg1ref, px1, py1, px2, py2, px3, py3, config.sighShape.baseHeight / 3, fillColor);
	leg1->rotate();
	point leg2ref = { RefPoint.x - config.sighShape.baseHeight / 4 , RefPoint.y - config.sighShape.topWdth / 8 - 5 };

	int spx1 = 3;
	int spy1 = 3;
	int spx2 = 3;
	int spy2 = 3;
	int spx3 = 3;
	int spy3 = 3;
	int temp_spx = spx1, temp_spy = spy1;
	spx1 = spx3;
	spy1 = spy3;
	spx3 = spx2;
	spy3 = spy2;
	spx2 = temp_spx;
	spy3 = temp_spy;
	leg2 = new Triangle(pGame, leg2ref, spx1, spy1, spx2, spy2, spx2, spy2, config.sighShape.baseHeight / 3, fillColor);
	leg2->rotate();
	numro++;
}
bool key::match(shape* other) const {
	const key* otherkey = dynamic_cast<const key*>(other);

	if (otherkey) {
		return (this->numre == other->getnumre() && this->numro == other->getnumro() && this->RefPoint.x == other->getRef().x && this->RefPoint.y == other->getRef().y);
	}
	return false;
}

////////////////////////////////////////////////////  class pencil  ///////////////////////////////////////

pencil::pencil(game* r_pGame, point ref,int PBodyHeight, int PBodywidth, int PTailrad, int PTipside, color FC) : shape(r_pGame, ref) {

	//PBodyHeight= config.sighShape.baseHeight
	//PBodywidth= config.sighShape.baseWdth
	//PTailrad= config.sighShape.baseWdth / 2
	//PTipside= config.sighShape.baseWdth * 0.29 * 3
	fillColor = FC;
	point bodyref = ref;
	point tailref = { ref.x, ref.y + PBodyHeight / 2 };
	point tipref = { ref.x,ref.y - PBodyHeight / 2 - PBodywidth * 0.29 };
	body = new Rect(pGame, bodyref, PBodyHeight, PBodywidth, fillColor);
	tail = new circle(pGame, tailref, PTailrad, fillColor);
	tip = new Triangle(pGame, tipref, 3, 3, 3, 3, 3, 3, PTipside, fillColor);
}
void pencil::draw() const {
	body->draw();
	tail->draw();
	tip->draw();

}
void pencil::move(point p) {
	body->move(p);
	tail->move(p);
	tip->move(p);
	this->setRefPoint(body->getRef());
}
void pencil::resizeUp()
{
	point bodyref = RefPoint;
	point tailref = { RefPoint.x, RefPoint.y + body->getheight() };
	point tipref = { RefPoint.x,RefPoint.y - body->getheight() - body->getwidth() };
	body->setRefPoint(bodyref);
	tail->setRefPoint(tailref);
	tip->setRefPoint(tipref);
	body->resizeUp();
	tail->resizeUp();
	tip->resizeUp();
	numre++;
}
void pencil::resizeDown()
{
	point bodyref = RefPoint;
	point tailref = { RefPoint.x, RefPoint.y + body->getheight() / 4 };
	point tipref = { RefPoint.x,RefPoint.y - body->getheight() / 4 - body->getwidth() / 4 };
	body->setRefPoint(bodyref);
	tail->setRefPoint(tailref);
	tip->setRefPoint(tipref);
	body->resizeDown();
	tail->resizeDown();
	tip->resizeDown();
	numre--;
}
void pencil::flip()
{
	body->flip();
	point tailref = { RefPoint.x, RefPoint.y - config.sighShape.baseHeight / 2 };
	tail = new circle(pGame, tailref, config.sighShape.baseWdth / 2, fillColor);
	tail->flip();

	int py1 = 3;
	int py2 = 3;
	int py3 = 3;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;

	point tipref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 0.29 };
	tip = new Triangle(pGame, tipref, 3, py1, 3, py2, 3, py3, config.sighShape.baseWdth * 0.29 * 3, fillColor);
	tip->flip();
}
void pencil::Save()
{
	ofstream progress("Progress1.txt");
	progress << "\n" << "\n" << "\n" << "\n" << "\n" << "\n";
	progress << RefPoint.x << "\n" << RefPoint.y << "\n";							// Line 5 -> x Ref point , Line 6 -> y Ref Point
	progress << body->getheight() << "\n" << body->getwidth() << "\n";				// Line 7 -> body height , Line 8 -> body width
	progress << tail->getradius() << "\n" << tip->getside() << "\n";				// Line 9 -> tail radius , Line 10 -> tip side

	progress.close();
}
void pencil::Load()
{

}
void pencil::rotate()
{
	point bodyref = RefPoint;
	body = new Rect(pGame, bodyref, config.sighShape.baseWdth, config.sighShape.baseHeight, fillColor);
	body->rotate();

	point tailref = { RefPoint.x - config.sighShape.baseHeight / 2, RefPoint.y };
	tail = new circle(pGame, tailref, config.sighShape.baseWdth / 2, fillColor);
	tail->rotate();

	point tipref = { RefPoint.x + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 0.29, RefPoint.y };

	int px1 = 3;
	int py1 = 3;
	int px2 = 3;
	int py2 = 3;
	int px3 = 3;
	int py3 = 3;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	tip = new Triangle(pGame, tipref, px1, py1, px2, py2, px3, py3, config.sighShape.baseWdth * 0.29 * 3, fillColor);
	tip->rotate();
	numro++;
}
bool pencil::match(shape* other) const {
	const pencil* otherpencil = dynamic_cast<const pencil*>(other);


	if (otherpencil) {
		return (this->numre == other->getnumre() && this->numro == other->getnumro() && this->RefPoint.x == other->getRef().x && this->RefPoint.y == other->getRef().y);
	}
	return false;
}
