#pragma once
#include "Basicshapes.h"


////////////////////////////////////////////////////  class Sign  ///////////////////////////////////////
//This class reprsents the composite shape "sign"
//The sign is composed of 2 Recatngles
/*				

					 ------------------
					|				   |
					|		 x		   |     x is the reference point of the Sign shape
					|			       |
					 ------------------
						   |   |
						   |   |
						   | . |
						   |   |
						   |   |
							---
*/

//Note: sign reference point is the center point of the top rectangle
class Sign :public shape
{
	Rect* base;
	Rect* top;
public:
	Sign(game* r_pGame, point ref, int height, int width, int , int,color FC);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);
	virtual void Save();
	virtual void Load();
	virtual bool match(shape* other) const override;

};

class House : public shape
{
	Rect* front;
	Triangle* roof;
	circle* window;
public:
	House(game* r_pGame, point ref,color FC);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);
	virtual void Save();
	virtual void Load();
	virtual bool match(shape* other) const override;

};

class Car : public shape
{
	Rect* body;
	circle* backwheel;
	circle* frontwheel;
	Triangle* frontbody;
public:
	Car(game* r_pGame, point ref, int BDheight, int BDwidth, int BWrad, int FWrad, int FBside, color FC);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);
	virtual void Save();
	virtual void Load();
	virtual bool match(shape* other) const override;

};

class Tree : public shape
{
	Triangle* leaf;
	Rect* bark;
public:
	Tree(game* r_pGame, point ref, int Bheight, int Bwidth, int Lside, color FC);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);
	virtual void Save();
	virtual void Load();
	virtual bool match(shape* other) const override;
};

class Lollipop : public shape
{
	Rect* stick;
	circle* candy;
public:
	Lollipop(game* r_pGame, point ref, int Sheight, int Swidth, int Crad, color FC);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);
	virtual void Save();
	virtual void Load();
	virtual bool match(shape* other) const override;
};

class robot : public shape
{
	Rect* body;
	circle* head;
	Triangle* leg;
public:
	robot(game* r_pGame, point ref, int RobotBodyHeight, int RobotBodyWidth, int RobotHeadrad, int RobotLegside, color FC);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);
	virtual void Save();
	virtual void Load();
	virtual bool match(shape* other) const override;

};

class key : public shape
{
	Rect* body;
	circle* head;
	Triangle* leg1;
	Triangle* leg2;
public:
	key(game* r_pGame, point ref, int KBodyHeight, int KBodyWidth, int KHeadrad ,int KLeg1side, int KLeg2side, color FC);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);
	virtual void Save();
	virtual void Load();
	virtual bool match(shape* other) const override;

};
class pencil : public shape
{
	Rect* body;
	circle* tail;
	Triangle* tip;
public:
	pencil(game* r_pGame, point ref, int PBodyHeight, int PBodywidth, int PTailrad, int PTipside, color FC);
	virtual void draw() const;
	virtual void resizeUp();
	virtual void resizeDown();
	virtual void rotate();
	virtual void flip();
	virtual void move(point p);
	virtual void Save();
	virtual void Load();
	virtual bool match(shape* other) const override;

};
