#include "operations.h"
#include "game.h"
#include "CompositeShapes.h"
#include <fstream>
#include <iostream>
#include <vector>






/////////////////////////////////// class operation  //////////////////
operation::operation(game* r_pGame)
{
	pGame = r_pGame;
}


/////////////////////////////////// class operAddSign  //////////////////

operAddSign::operAddSign(game* r_pGame):operation(r_pGame)
{
}
operAddTriangle::operAddTriangle(game* r_pGame):operation(r_pGame)
{
}
operAddcircle::operAddcircle(game* r_pGame) :operation(r_pGame)
{
}
operAddRectangle::operAddRectangle(game* r_pGame):operation(r_pGame)
{
}
operAddHouse::operAddHouse(game* r_pGame) :operation(r_pGame)
{
}
operAddCar::operAddCar(game* r_pGame) :operation(r_pGame)
{
}
operAddTree::operAddTree(game* r_pGame) :operation(r_pGame)
{
}
operAddLollipop::operAddLollipop(game* r_pGame) :operation(r_pGame)
{
}
operAddrobot::operAddrobot(game* r_pGame) :operation(r_pGame)
{
}
operAddkey::operAddkey(game* r_pGame) :operation(r_pGame)
{
}
operAddpencil::operAddpencil(game* r_pGame) :operation(r_pGame)
{
}
operRotate::operRotate(game* r_pGame) :operation(r_pGame)
{
}
operHint::operHint(game* r_pGame) :operation(r_pGame)
{
}
operRefresh::operRefresh(game* r_pGame) :operation(r_pGame)
{
}
operDelete::operDelete(game* r_pGame) :operation(r_pGame)
{
}
operIncrease::operIncrease(game* r_pGame) :operation(r_pGame)
{
}
operDecrease::operDecrease(game* r_pGame) :operation(r_pGame)
{
}
operSelectLevel::operSelectLevel(game* r_pGame) : operation(r_pGame)
{
}
operSave::operSave(game* r_pGame) : operation(r_pGame)
{
}
operflip::operflip(game* r_pGame) : operation(r_pGame)
{
}
operLoad::operLoad(game* r_pGame) : operation(r_pGame)
{
}



void operAddSign::Act()
{
	window* pw = pGame->getWind();

	//TODO:
	// Don't allow adding new shape if there is alreday an active shape

	//align reference point to the nearest grid point
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefX % config.gridSpacing;

	//take the aligned point as the sign shape ref point
	point signShapeRef = { xGrid,yGrid };

	//create a sign shape
	shape* psh = new Sign(pGame, signShapeRef, config.sighShape.topHeight, config.sighShape.topWdth, config.sighShape.baseHeight, config.sighShape.baseWdth,RED);

	//Add the shape to the grid
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);

}

void operAddTriangle::Act()
{
	window* pw = pGame->getWind();

	//TODO:
	// Don't allow adding new shape if there is alreday an active shape

	//align reference point to the nearest grid point
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefX % config.gridSpacing;

	//take the aligned point as the sign shape ref point
	point signShapeRef = { xGrid,yGrid };

	//create a sign shape
	shape* psh = new Triangle(pGame, signShapeRef, 30, 40, 60, 60, 60, 60, 60, RED);

	//Add the shape to the grid
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);

}


void operAddcircle::Act()
{
	{
		window* pw = pGame->getWind();

		//TODO:
		// Don't allow adding new shape if there is alreday an active shape

		//align reference point to the nearest grid point
		int xGrid = config.RefX - config.RefX % config.gridSpacing;
		int yGrid = config.RefY - config.RefX % config.gridSpacing;

		//take the aligned point as the sign shape ref point
		point signShapeRef = { xGrid,yGrid };


		//create a sign shape
		shape* psh = new circle(pGame, signShapeRef, 50, RED);
		//Add the shape to the grid
		grid* pGrid = pGame->getGrid();
		pGrid->setActiveShape(psh);

	}
}
void operAddRectangle::Act()
{
	window* pw = pGame->getWind();

	//TODO:
	// Don't allow adding new shape if there is alreday an active shape

	//align reference point to the nearest grid point
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefX % config.gridSpacing;

	//take the aligned point as the sign shape ref point
	point signShapeRef = { xGrid,yGrid };

	//create a sign shape
	shape* psh = new Rect(pGame, signShapeRef,60,50, RED);

	//Add the shape to the grid
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);

}


void operAddHouse::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new House(pGame, signShapeRef, RED);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}
void operAddCar::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new Car(pGame, signShapeRef, config.sighShape.topHeight, config.sighShape.topWdth, 1.2 * config.sighShape.baseWdth, 1.2 * config.sighShape.baseWdth, config.sighShape.topWdth / 2.5, RED);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}
void operAddTree::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new Tree(pGame, signShapeRef, config.sighShape.baseHeight, config.sighShape.topWdth / 4, config.sighShape.baseHeight * 3 / 4, RED);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}

void operAddLollipop::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new Lollipop(pGame, signShapeRef, config.sighShape.baseHeight * 1.5,config.sighShape.baseWdth, config.sighShape.topWdth * 3 / 8, RED);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}

void operAddrobot::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new robot(pGame, signShapeRef, config.sighShape.baseHeight, config.sighShape.topWdth / 2, config.sighShape.topWdth / 4, config.sighShape.baseHeight / 1.5, RED);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}

void operAddkey::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new key(pGame, signShapeRef, config.sighShape.baseHeight, config.sighShape.topWdth / 4, config.sighShape.baseWdth * 1.5, config.sighShape.baseHeight / 3, config.sighShape.baseHeight / 3, RED);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}

void operAddpencil::Act() {
	window* pw = pGame->getWind();
	int xGrid = config.RefX - config.RefX % config.gridSpacing;
	int yGrid = config.RefY - config.RefY % config.gridSpacing;
	point signShapeRef = { xGrid, yGrid };
	shape* psh = new pencil(pGame, signShapeRef, config.sighShape.baseHeight, config.sighShape.baseWdth, config.sighShape.baseWdth / 2, config.sighShape.baseWdth * 0.29 * 3, RED);
	grid* pGrid = pGame->getGrid();
	pGrid->setActiveShape(psh);
}

operDeleteShape::operDeleteShape(game* r_pGame) :operation(r_pGame)
{
}

void operDeleteShape::Act()
{
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	pGrid->Delete();
}

void operRotate::Act()
{
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	shape* psh = pGrid->getActiveShape();
	if (psh != nullptr)
		psh->rotate();
}
void operflip::Act()
{
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	shape* psh = pGrid->getActiveShape();
	if (psh != nullptr)
		psh->flip();
}
void operHint::Act()
{


}
void operRefresh::Act()
{


	/*pGame->setlives();*/
}
void operDelete::Act() {

}
void operIncrease::Act()
{

}
void operDecrease::Act()
{

}
void operSelectLevel::Act()
{
	int l = (pGame->getLvl() * 2) - 1;
	for (int i = 0; i < l; i++)
		/*shapeList[i] = nullptr;*/
		window* pw = pGame->getWind();
	grid* hm = pGame->getGrid();
	pGame->SelecLvl();
	hm->randomshapes();
	pGame->givensteps();
}

operResizeUp::operResizeUp(game* r_pGame) :operation(r_pGame)
{
}
operResizeDown::operResizeDown(game* r_pGame) :operation(r_pGame)
{
}
void operResizeUp::Act() {
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	shape* psh = pGrid->getActiveShape();
	if (psh != nullptr)
		psh->resizeUp();
}

void operResizeDown::Act() {
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	shape* psh = pGrid->getActiveShape();
	if (psh != nullptr)
		psh->resizeDown();
}

void operSave::Act() {
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	shape* psh = pGrid->getActiveShape();
	vector<toolbarItem> tbv = pGame->getvector();
	ofstream progress("Progress1.txt");
	progress << pGame->getLives() << "\n" << pGame->getLvl() << "\n" << pGame->getScore()<<"\n"/*<< tbv[0]*/; //Line 1 -> Lives , Line 2 -> Level , Line 3 -> Score , Line 4 -> shape 
	for (int i = 0; i < tbv.size(); i++)
	{
		progress << tbv[i];
	}
	psh->Save();
	progress.close();
}



void operLoad::Act()
{
	window* pw = pGame->getWind();
	grid* pGrid = pGame->getGrid();
	int lives, lvl, score, shape, rx, ry;
	ifstream progress("Progress1.txt");
	progress >> lives >> lvl >> score >> shape >> rx >> ry;
	pGame->setlives(lives);
	pGame->setlevel(lvl);
	pGame->setscore(score);
	
	point ref;
	ref.x = rx;
	ref.y = ry;
	
	switch (shape) //0 Sign, 1 Car, 2 Tree , 3 lollipop , 4 key , 5 pencil , 6 Robot
	{
	case(0): 
		int  Topheight, Topwidth, Baseheight, Basewidth;
		for (int i = 0; i < 10; i++)
		{
			if (i >= 6) 
			{
				progress >> Topheight >> Topwidth >> Baseheight >> Basewidth;
			}
		}
		pGrid->setActiveShape(new Sign(pGame,ref, Topheight, Topwidth, Baseheight, Basewidth, RED));
		progress.close();
		break;
	case(1):
		int  BDheight, BDwidth, BWrad, FWrad, FBside;
		for (int i = 0; i < 11; i++)
		{
			if (i >= 6) 
			{
				progress >> BDheight >> BDwidth >> BWrad >> FWrad >> FBside;
			}
		}
		pGrid->setActiveShape(new Car(pGame, ref, BDheight, BDwidth, BWrad, FWrad, FBside, RED));
		progress.close();
		break;
	case(2):
		int Barkheight, Barkwidth, Leafside;
		for (int i = 0; i < 9; i++)
		{
			if (i >= 6)
			{
				progress >> Barkheight>> Barkwidth>> Leafside;
			}
		}
		pGrid->setActiveShape(new Tree(pGame, ref, Barkheight, Barkwidth, Leafside, RED));
		progress.close();
		break;
	case(3):
		int Sheight, Swidth, Crad;
		for (int i = 0; i < 9; i++)
		{
			if (i >= 6)
			{
				progress >> Sheight>> Swidth>> Crad;
			}
		}
		pGrid->setActiveShape(new Lollipop(pGame, ref, Sheight, Swidth, Crad, RED));
		progress.close();
		break;
	case(4):
		int KBodyHeight, KBodyWidth, KHeadrad, KLeg1side, KLeg2side;
		for (int i = 0; i < 11; i++)
		{
			if (i >= 6)
			{
				progress >> KBodyHeight>> KBodyWidth>> KHeadrad>> KLeg1side>> KLeg2side;
			}
		}
		pGrid->setActiveShape(new key(pGame, ref, KBodyHeight, KBodyWidth, KHeadrad, KLeg1side, KLeg2side, RED));
		progress.close();
		break;
	case(5):
		int PBodyHeight, PBodywidth, PTailrad, PTipside;
		for (int i = 0; i < 10; i++)
		{
			if (i >= 6)
			{
				progress >> PBodyHeight>> PBodywidth>> PTailrad>> PTipside;
			}
		}
		pGrid->setActiveShape(new pencil(pGame, ref, PBodyHeight, PBodywidth, PTailrad, PTipside, RED));
		progress.close();
		break;
	case(6):
		int RobotBodyHeight, RobotBodyWidth, RobotHeadrad, RobotLegside;
		for (int i = 0; i < 10; i++)
		{
			if (i >= 6)
			{
				progress >> RobotBodyHeight>> RobotBodyWidth>> RobotHeadrad>> RobotLegside;
			}
		}
		pGrid->setActiveShape(new robot(pGame, ref, RobotBodyHeight, RobotBodyWidth, RobotHeadrad, RobotLegside, RED));
		progress.close();
		break;

	}

	
}
