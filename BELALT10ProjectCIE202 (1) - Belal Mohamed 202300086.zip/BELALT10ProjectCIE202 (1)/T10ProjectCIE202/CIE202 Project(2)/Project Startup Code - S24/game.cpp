#include "game.h"
#include "gameConfig.h"



game::game()
{

	//Create the main window
	createWind(config.windWidth, config.windHeight, config.wx, config.wy);
	lvl = 1, score = 0, lives = 5;
	//Create and draw the toolbar
	createToolBar();

	//Create and draw the grid
	createGrid();
	shapesGrid->draw();	//draw the grid and all shapes it contains.

	//Create and clear the status bar
	clearStatusBar();


}

game::~game()
{
	delete pWind;
	delete shapesGrid;
}
/////////////////////////////////////////////////////////////////////////////////////////
//draws the integer 
int game::getLvl() const {
	return lvl;
}

int game::getLives() const {
	return lives;
}

int game::getScore() const {
	return score;
}


//////////////////////////////////////////////////////////////////////////////////////////
void game::createWind(int w, int h, int x, int y) 
{
	pWind = new window(w, h, x, y);
	pWind->SetBrush(config.bkGrndColor);
	pWind->SetPen(config.bkGrndColor, 1);
	pWind->DrawRectangle(0, 0, w, h);
}
//////////////////////////////////////////////////////////////////////////////////////////
void game::clearStatusBar() const
{
	//Clear Status bar by drawing a filled rectangle
	pWind->SetPen(config.statusBarColor, 1);
	pWind->SetBrush(config.statusBarColor);
	pWind->DrawRectangle(0, config.windHeight - config.statusBarHeight, config.windWidth, config.windHeight);
}

//////////////////////////////////////////////////////////////////////////////////////////
//Draws the menu (toolbar) in the mode
void game::createToolBar()
{
	gameToolbar = new toolbar(this);
}

void game::createGrid()
{	
	//calc some grid parameters
	point gridUpperLeftPoint = { 0, config.toolBarHeight };
	int gridHeight = config.windHeight - config.toolBarHeight - config.statusBarHeight;
	//create the grid
	shapesGrid = new grid(gridUpperLeftPoint, config.windWidth, gridHeight, this);
}

operation* game::createRequiredOperation(toolbarItem clickedItem)
{
	
	operation* op=nullptr;
	switch (clickedItem)
	{
	case ITM_SIGN:
		op = new operAddSign(this);
		printMessage("You Draw a Sign");
		break;
	//case ITM_Triangle:
	//	op = new operAddTriangle(this);
	//	printMessage("You Draw a Triangle");
	//	break;
	//case ITM_circle:
	//	op = new operAddcircle(this);
	//	printMessage("You Draw a Circle");
	//	break;
	//case ITM_Rectangle:
	//	op = new operAddRectangle(this);
	//	printMessage("You Draw a Rectangle");
	//	break;
	//case ITM_House:
	//	op = new operAddHouse(this);
	//	printMessage("You Draw a House");
	//	break;
	case ITM_Car:
		op = new operAddCar(this);
		printMessage("You Draw a Car");
		break;
	case ITM_pencil:
		op = new operAddpencil(this);
		printMessage("You Draw a pencil");
		break;
	case ITM_robot:
		op = new operAddrobot(this);
		printMessage("You Draw a robot");
		break;
	case ITM_key:
		op = new operAddkey(this);
		printMessage("You Draw a key");
		break;
	case ITM_tree:
		op = new operAddTree(this);
		printMessage("You Draw a tree");
		break;
	case ITM_lollipop:
		op = new operAddLollipop(this);
		printMessage("You Draw a lollipop");
		break;
	case ITM_Increase:

		printMessage("You Increased the shape's size");
		break;
	case ITM_Decrease:
		
		printMessage("You Decreased the shape's size");
		break;
	case ITM_Refresh:
		
		printMessage("You Refreshed the window");
		break;
	case ITM_Delete:
		op = new operDeleteShape(this);
		printMessage("You deleted the shape");
		break;

	/*case ITM_Horse:
		op = new operAddHorse(this);
		break;*/
	}
	
	return op;
}


//////////////////////////////////////////////////////////////////////////////////////////

void game::printMessage(string msg) const	//Prints a message on status bar
{
	clearStatusBar();	//First clear the status bar

	pWind->SetPen(config.penColor, 50);
	pWind->SetFont(24, BOLD, BY_NAME, "Arial");
	pWind->DrawString(10, config.windHeight - (int)(0.85 * config.statusBarHeight), msg);
}



window* game::getWind() const		//returns a pointer to the graphics window
{
	return pWind;
}



string game::getSrting() const
{
	string Label;
	char Key;
	keytype ktype;
	pWind->FlushKeyQueue();
	while (1)
	{
		ktype = pWind->WaitKeyPress(Key);
		if (ktype == ESCAPE)	//ESCAPE key is pressed
			return "";	//returns nothing as user has cancelled label
		if (Key == 13)	//ENTER key is pressed
			return Label;
		if (Key == 8)	//BackSpace is pressed
			if (Label.size() > 0)
				Label.resize(Label.size() - 1);
			else
				Key = '\0';
		else
			Label += Key;
		printMessage(Label);
	}
}

grid* game::getGrid() const
{
	// TODO: Add your implementation code here.
	return shapesGrid;
}



////////////////////////////////////////////////////////////////////////
void game::run() 
{
	//This function reads the position where the user clicks to determine the desired operation
	int x, y;
	bool isExit = false;

	//Change the title
	pWind->ChangeTitle("- - - - - - - - - - SHAPE HUNT (CIE 101 / CIE202 - project) - - - - - - - - - -");
	toolbarItem clickedItem=ITM_CNT;
	do
	{
		//printMessage("Ready...");
		//1- Get user click
		pWind->WaitMouseClick(x, y);	//Get the coordinates of the user click

		//2-Explain the user click
		//If user clicks on the Toolbar, ask toolbar which item is clicked
		if (y >= 0 && y < config.toolBarHeight)
		{
			clickedItem=gameToolbar->getItemClicked(x);

			//3-create the approp operation accordin to item clicked by the user
			operation* op = createRequiredOperation(clickedItem);
			if (op)
				op->Act();

			//4-Redraw the grid after each action
			if(clickedItem!= ITM_Delete)
			shapesGrid->draw();

		}	

	} while (clickedItem!=ITM_EXIT);
}