#include "game.h"


int main()
{

	//Create an object of controller
	game Game;
	
	Game.run();

	
	return 0;
}

