#include "CompositeShapes.h"
#include "gameConfig.h"

////////////////////////////////////////////////////  class Sign  ///////////////////////////////////////
Sign::Sign(game* r_pGame, point ref):shape(r_pGame, ref)
{
	//calc the ref point of the Sign base and top rectangles relative to the Sign shape
	point topRef = ref;	//top rect ref is the same as the sign
	point baseRef = { ref.x, ref.y + config.sighShape.topHeight / 2  + config.sighShape.baseHeight / 2  };
	top = new Rect(pGame, topRef, config.sighShape.topHeight, config.sighShape.topWdth );
	base = new Rect(pGame, baseRef, config.sighShape.baseHeight, config.sighShape.baseWdth);
}

void Sign::draw() const
{
	base->draw();
	top->draw();
}
void Sign::resizeUp()
{
	config.sighShape.topHeight = config.sighShape.topHeight * sqrt(2);
	config.sighShape.topWdth = config.sighShape.topWdth * sqrt(2);
	config.sighShape.baseHeight = config.sighShape.baseHeight * sqrt(2);
	config.sighShape.baseWdth = config.sighShape.baseWdth * sqrt(2);
}
void Sign::resizeDown()
{
	config.sighShape.topHeight = config.sighShape.topHeight / sqrt(2);
	config.sighShape.topWdth = config.sighShape.topWdth / sqrt(2);
	config.sighShape.baseHeight = config.sighShape.baseHeight / sqrt(2);
	config.sighShape.baseWdth = config.sighShape.baseWdth / sqrt(2);
}
void Sign::flip()
{


	top->draw();
	point baseRef = { RefPoint.x, RefPoint.y - config.sighShape.topHeight / 2 - config.sighShape.baseHeight / 2 };
	base = new Rect(pGame, baseRef, config.sighShape.baseHeight, config.sighShape.baseWdth);
	base->draw();
}
void Sign::rotate()
{
	point topRef = RefPoint;
	top = new Rect(pGame, topRef, config.sighShape.topWdth, config.sighShape.topHeight);
	top->draw();
	point baseRef = { RefPoint.x, RefPoint.y - config.sighShape.topHeight / 2 - config.sighShape.baseHeight / 2 };
	base = new Rect(pGame, baseRef, config.sighShape.baseWdth, config.sighShape.baseHeight);
	base->draw();
}

////////////////////////////////////////////////////  class House  ///////////////////////////////////////

House::House(game* r_pGame, point ref) :shape(r_pGame, ref) {
	point frontref = ref;
	point roofref = { ref.x, ref.y - config.sighShape.topHeight * 1.5  - config.sighShape.baseWdth +20 };
	point windowref = { ref.x,ref.y - config.sighShape.topHeight * 1.5 / 2 - config.sighShape.baseWdth / 3 };
	front = new Rect(pGame, frontref, config.sighShape.topHeight * 1.5, config.sighShape.topWdth*0.8);
	roof = new Triangle(pGame, roofref, ref.x, ref.y - config.sighShape.topHeight * 3/4 - 3 * config.sighShape.baseWdth, ref.x - config.sighShape.topWdth / 2-3 * config.sighShape.baseWdth, ref.y - config.sighShape.topHeight * 1.5 / 2, ref.x + config.sighShape.topWdth / 2, ref.y - config.sighShape.topHeight * 1.5 / 2, 0.86*config.sighShape.topWdth);
	window = new circle(pGame, windowref, config.sighShape.topHeight/2.5);
}
void House::draw() const {
	front->draw();
	roof->draw();
	window->draw();
}
void House::resizeUp()
{

}
void House::resizeDown()
{

}
void House::rotate()
{

}
void House::flip()
{

}

////////////////////////////////////////////////////  class Car  ///////////////////////////////////////

Car::Car(game* r_pGame, point ref) :shape(r_pGame, ref) {
	point bodyref = ref;
	point backwheelref = { ref.x - config.sighShape.topWdth / 2 + 1.2 * config.sighShape.baseWdth,ref.y + config.sighShape.topHeight / 2 + 1.2 * config.sighShape.baseWdth };
	point frontwheelref = { ref.x + config.sighShape.topWdth / 2 - 1.2 * config.sighShape.baseWdth,ref.y + config.sighShape.topHeight / 2 + 1.2 * config.sighShape.baseWdth };
	point frontbodyref = { ref.x+ config.sighShape.topWdth/2,ref.y };
	body = new Rect(pGame, bodyref, config.sighShape.topHeight, config.sighShape.topWdth);
	backwheel = new circle(pGame, backwheelref, 1.2* config.sighShape.baseWdth);
	frontwheel = new circle(pGame, frontwheelref, 1.2* config.sighShape.baseWdth);
	frontbody = new Triangle(pGame, frontbodyref, 3, 3, 3, 3, 3, 3, config.sighShape.topWdth/2.5);
	
}

void Car::draw() const {
	frontwheel->draw();
	body->draw();
	backwheel->draw();
	frontbody->draw();
}
void Car::resizeUp()
{
	config.sighShape.topWdth = config.sighShape.topWdth * 2;
	config.sighShape.baseWdth = config.sighShape.baseWdth * 2;
	config.sighShape.topHeight = config.sighShape.topHeight * 2;

}

void Car::resizeDown()
{
	config.sighShape.topWdth = config.sighShape.topWdth / 2;
	config.sighShape.baseWdth = config.sighShape.baseWdth / 2;
	config.sighShape.topHeight = config.sighShape.topHeight / 2;
}
void Car::flip()
{
	body->draw();

	point backwheelref = { RefPoint.x - config.sighShape.topWdth / 2 + 1.2 * config.sighShape.baseWdth,RefPoint.y - config.sighShape.topHeight / 2 - 1.2 * config.sighShape.baseWdth };
	backwheel->draw();

	point frontwheelref = { RefPoint.x + config.sighShape.topWdth / 2 - 1.2 * config.sighShape.baseWdth,RefPoint.y - config.sighShape.topHeight / 2 - 1.2 * config.sighShape.baseWdth };
	frontwheel->draw();

	int py1 = 3;
	int py2 = 3;
	int py3 = 3;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;

	point frontbodyref = { RefPoint.x + config.sighShape.topWdth / 2,RefPoint.y };
	frontbody = new Triangle(pGame, frontbodyref, 3, py1, 3, py2, 3, py3, 40);
	frontbody->draw();


}
void Car::rotate()
{
	point bodyref = RefPoint;
	body = new Rect(pGame, bodyref, config.sighShape.topWdth, config.sighShape.topHeight);
	body->draw();

	point backwheelref = { RefPoint.x - config.sighShape.topWdth / 2 - 1.2 * config.sighShape.baseWdth,RefPoint.y - config.sighShape.topHeight / 2 + 1.2 * config.sighShape.baseWdth };
	backwheel = new circle(pGame, backwheelref, 1.2 * config.sighShape.baseWdth);
	backwheel->draw();

	point frontwheelref = { RefPoint.x - config.sighShape.topWdth / 2 - 1.2 * config.sighShape.baseWdth,RefPoint.y + config.sighShape.topHeight / 2 - 1.2 * config.sighShape.baseWdth };
	frontwheel = new circle(pGame, frontwheelref, 1.2 * config.sighShape.baseWdth);
	frontwheel->draw();

	point frontbodyref = { RefPoint.x ,RefPoint.y + config.sighShape.topWdth / 2 };
	int px1 = 3;
	int px2 = 3;
	int px3 = 3;
	int py1 = 3;
	int py2 = 3;
	int py3 = 3;
	int temp_x = px1, temp_y = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_x;
	py2 = temp_y;
	frontbody = new Triangle(pGame, frontbodyref, px1, py1, px2, py2, px3, py3, config.sighShape.topWdth / 2.5);
	frontbody->draw();

}
////////////////////////////////////////////////////  class Tree  ///////////////////////////////////////

Tree::Tree(game* r_pGame, point ref) : shape(r_pGame, ref) {
	point barkref = ref;
	point leafref = { ref.x,ref.y - config.sighShape.baseHeight / 2 };
	bark = new Rect(pGame, barkref, config.sighShape.baseHeight, config.sighShape.topWdth / 4);
	leaf = new Triangle(pGame, leafref, ref.x, ref.y - config.sighShape.baseHeight * 3 / 4, ref.x - config.sighShape.topWdth * 1.5, ref.y, ref.x + config.sighShape.topWdth * 1.5, ref.y, config.sighShape.baseHeight * 3 / 4);
}
void Tree::draw() const {
	bark->draw();
	leaf->draw();
}

void Tree::resizeUp()
{
	config.sighShape.baseHeight = config.sighShape.baseHeight * 2;
	config.sighShape.topWdth = config.sighShape.topWdth * 2;
}

void Tree::resizeDown()
{
	config.sighShape.baseHeight = config.sighShape.baseHeight / 2;
	config.sighShape.topWdth = config.sighShape.topWdth / 2;
}
void Tree::flip()
{

	bark->draw();
	point leafref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 };


	int py1 = 300 - config.sighShape.baseHeight * 3 / 4;
	int py2 = 300;
	int py3 = 300;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;

	leaf = new Triangle(pGame, leafref, RefPoint.x, py1, RefPoint.x - config.sighShape.topWdth * 1.5, py2, RefPoint.x + config.sighShape.topWdth * 1.5, py3, config.sighShape.baseHeight * 3 / 4);
	leaf->draw();

}
void Tree::rotate() {

	point barkref = RefPoint;
	bark = new Rect(pGame, barkref, config.sighShape.topWdth / 4, config.sighShape.baseHeight);
	bark->draw();

	point leafref = { RefPoint.x,RefPoint.y - config.sighShape.baseHeight / 2 };
	int px1 = 800;
	int py1 = 300 - config.sighShape.baseHeight * 3 / 4;
	int px2 = 800 - config.sighShape.topWdth * 1.5;
	int py2 = 300;
	int px3 = 800 + config.sighShape.topWdth * 1.5;
	int py3 = 300;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	leaf = new Triangle(pGame, leafref, px1, py1, px2, py2, px3, py3, config.sighShape.baseHeight * 3 / 4);
	leaf->draw();

}
////////////////////////////////////////////////////  class Lollipop  ///////////////////////////////////////

Lollipop::Lollipop(game* r_pGame, point ref) : shape(r_pGame, ref) {
	point stickref = ref;
	point candyref = { ref.x,ref.y - config.sighShape.baseHeight / 2 };
	stick = new Rect(pGame, stickref, config.sighShape.baseHeight*1.5, config.sighShape.baseWdth);
	candy = new circle(pGame, candyref, config.sighShape.topWdth * 3 / 8);
}
void Lollipop::draw() const {
	stick->draw();
	candy->draw();
}

void Lollipop::resizeUp()
{
	config.sighShape.baseHeight = config.sighShape.baseHeight * 2;
	config.sighShape.baseWdth = config.sighShape.baseWdth * 2;
}

void Lollipop::resizeDown()
{
	config.sighShape.baseHeight = config.sighShape.baseHeight / 2;
	config.sighShape.baseWdth = config.sighShape.baseWdth / 2;
}
void Lollipop::flip()
{

	stick->draw();
	point candyref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 };
	candy = new circle(pGame, candyref, config.sighShape.topWdth * 3 / 8);
	candy->draw();



}
void Lollipop::rotate() {
	point stickref = RefPoint;

	int x = config.sighShape.topHeight;
	config.sighShape.topHeight = config.sighShape.topWdth;
	config.sighShape.topWdth = x;

	stick = new Rect(pGame, stickref, config.sighShape.baseHeight, config.sighShape.baseWdth * 1.5);
	stick->draw();


	point candyref = { RefPoint.x + config.sighShape.baseHeight / 2, RefPoint.y };
	candy = new circle(pGame, candyref, config.sighShape.topWdth * 3 / 8);
	candy->draw();
}


////////////////////////////////////////////////////  class robot  ///////////////////////////////////////

robot::robot(game* r_pGame, point ref) : shape(r_pGame, ref) {
	point bodyref = ref;
	point headref = { ref.x,ref.y - config.sighShape.baseHeight / 2 - config.sighShape.topWdth / 4 };
	point legref = { ref.x ,ref.y + config.sighShape.baseHeight/ 4 +20 };
	body = new Rect(pGame, bodyref, config.sighShape.baseHeight, config.sighShape.topWdth / 2);
	head = new circle(pGame, headref, config.sighShape.topWdth / 4);
	leg = new Triangle(pGame, legref, ref.x - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3, ref.y + config.sighShape.baseHeight / 2, ref.x - config.sighShape.topWdth / 4, ref.y + config.sighShape.baseHeight / 2, ref.x - config.sighShape.topWdth / 4, ref.y + config.sighShape.baseHeight / 4, config.sighShape.baseHeight /1.5 );

}
void robot::draw() const {
	body->draw();
	head->draw();
	leg->draw();
}

void robot::resizeUp()
{
	config.sighShape.baseHeight = config.sighShape.baseHeight * 2;
	config.sighShape.topWdth = config.sighShape.topWdth * 2;
	config.sighShape.baseWdth = config.sighShape.baseWdth * 2;
}

void robot::resizeDown()
{
	config.sighShape.baseHeight = config.sighShape.baseHeight / 2;
	config.sighShape.topWdth = config.sighShape.topWdth / 2;
	config.sighShape.baseWdth = config.sighShape.baseWdth / 2;
}

void robot::flip()
{
	body->draw();
	point headref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 + config.sighShape.topWdth / 4 };
	head = new circle(pGame, headref, config.sighShape.topWdth / 4);
	point legref = { RefPoint.x ,RefPoint.y - config.sighShape.baseHeight / 4 - 20 };

	int py1 = 300 + config.sighShape.baseHeight / 2;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;
	leg = new Triangle(pGame, legref, RefPoint.x - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3, py1, RefPoint.x - config.sighShape.topWdth / 4, py2, RefPoint.x - config.sighShape.topWdth / 4, py3, config.sighShape.baseHeight / 1.5);
	leg->draw();
}

void robot::rotate()
{
	point bodyref = RefPoint;
	body = new Rect(pGame, bodyref, config.sighShape.topWdth / 2, config.sighShape.baseHeight);
	body->draw();

	point headref = { RefPoint.x - config.sighShape.baseHeight / 2 - config.sighShape.topWdth / 4 ,RefPoint.y };
	head = new circle(pGame, headref, config.sighShape.topWdth / 4);
	head->draw();

	point legref = { RefPoint.x ,RefPoint.y + config.sighShape.baseHeight / 4 + 20 };
	int px1 = 800 - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3;
	int py1 = 300 + config.sighShape.baseHeight / 2;
	int px2 = 800 - config.sighShape.topWdth / 4;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int px3 = 800 - config.sighShape.topWdth / 4;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	leg = new Triangle(pGame, legref, px1, py1, px2, py2, px3, py3, config.sighShape.baseHeight / 1.5);
	leg->draw();


}


key::key(game* r_pGame, point ref) : shape(r_pGame, ref) {
	point bodyref = ref;
	point headref = { ref.x,ref.y - config.sighShape.baseHeight / 2 - config.sighShape.baseWdth * 1.2 };
	point leg1ref = { ref.x - config.sighShape.topWdth / 8,ref.y - config.sighShape.baseHeight / 6 };
	point leg2ref = { ref.x - config.sighShape.topWdth / 8,ref.y + config.sighShape.baseHeight / 4 };
	body = new Rect(pGame, bodyref, config.sighShape.baseHeight, config.sighShape.topWdth / 4);
	head = new circle(pGame, headref, config.sighShape.baseWdth * 1.5);
	leg1 = new Triangle(pGame, leg1ref, ref.x - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3, ref.y + config.sighShape.baseHeight / 2, ref.x - config.sighShape.topWdth / 4, ref.y + config.sighShape.baseHeight / 2, ref.x - config.sighShape.topWdth / 4, ref.y + config.sighShape.baseHeight / 4, config.sighShape.baseHeight / 3);
	leg2 = new Triangle(pGame, leg2ref, 3, 3, 3, 3, 3, 3, config.sighShape.baseHeight / 3);
}
void key::draw() const {
	body->draw();
	head->draw();
	leg1->draw();
	leg2->draw();
}
void key::resizeUp()
{
	config.sighShape.baseHeight = config.sighShape.baseHeight * 2;
	config.sighShape.topWdth = config.sighShape.topWdth * 2;
	config.sighShape.baseWdth = config.sighShape.baseWdth * 2;
}

void key::resizeDown()
{
	config.sighShape.baseHeight = config.sighShape.baseHeight / 2;
	config.sighShape.topWdth = config.sighShape.topWdth / 2;
	config.sighShape.baseWdth = config.sighShape.baseWdth / 2;
}
void key::flip()
{
	int py1 = 300 + config.sighShape.baseHeight / 2;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;
	int spy1 = 3;
	int spy2 = 3;
	int spy3 = 3;
	int temp_spy = spy1;
	spy1 = spy3;
	spy2 = temp_spy;
	spy3 = temp_spy;

	body->draw();
	point headref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 1.2 };
	head = new circle(pGame, headref, config.sighShape.baseWdth * 1.5);
	head->draw();
	point leg1ref = { RefPoint.x - config.sighShape.topWdth / 8,RefPoint.y + config.sighShape.baseHeight / 6 };
	leg1 = new Triangle(pGame, leg1ref, RefPoint.x - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3, py1, RefPoint.x - config.sighShape.topWdth / 4, py2, RefPoint.x - config.sighShape.topWdth / 4, py3, config.sighShape.baseHeight / 3);
	leg1->draw();
	point leg2ref = { RefPoint.x - config.sighShape.topWdth / 8,RefPoint.y + config.sighShape.baseHeight / 4 };
	leg2 = new Triangle(pGame, leg2ref, 3, spy1, 3, spy2, 3, spy3, config.sighShape.baseHeight / 3);
	leg2->draw();

}
void key::rotate()
{
	point bodyref = RefPoint;
	body = new Rect(pGame, bodyref, config.sighShape.topWdth / 4, config.sighShape.baseHeight);
	body->draw();

	point headref = { RefPoint.x + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 1.2,RefPoint.y };
	head = new circle(pGame, headref, config.sighShape.baseWdth * 1.5);
	head->draw();

	point leg1ref = { RefPoint.x + config.sighShape.baseHeight / 6 ,RefPoint.y - config.sighShape.topWdth / 8 };

	int px1 = 800 - config.sighShape.topWdth / 4 - config.sighShape.baseWdth * 3;
	int py1 = 300 + config.sighShape.baseHeight / 2;
	int px2 = 800 - config.sighShape.topWdth / 4;
	int py2 = 300 + config.sighShape.baseHeight / 2;
	int px3 = 800 - config.sighShape.topWdth / 4;
	int py3 = 300 + config.sighShape.baseHeight / 4;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	leg1 = new Triangle(pGame, leg1ref, px1, py1, px2, py2, px3, py3, config.sighShape.baseHeight / 3);
	leg1->draw();
	point leg2ref = { RefPoint.x - config.sighShape.baseHeight / 4 , RefPoint.y - config.sighShape.topWdth / 8 };

	int spx1 = 3;
	int spy1 = 3;
	int spx2 = 3;
	int spy2 = 3;
	int spx3 = 3;
	int spy3 = 3;
	int temp_spx = spx1, temp_spy = spy1;
	spx1 = spx3;
	spy1 = spy3;
	spx3 = spx2;
	spy3 = spy2;
	spx2 = temp_spx;
	spy3 = temp_spy;
	leg2 = new Triangle(pGame, leg2ref, spx1, spy1, spx2, spy2, spx2, spy2, config.sighShape.baseHeight / 3);
	leg2->draw();

}

pencil::pencil(game* r_pGame, point ref) : shape(r_pGame, ref) {
	point bodyref = ref;
	point tailref = { ref.x, ref.y + config.sighShape.baseHeight / 2 };
	point tipref = { ref.x,ref.y - config.sighShape.baseHeight / 2 - config.sighShape.baseWdth * 0.29 };
	body = new Rect(pGame, bodyref, config.sighShape.baseHeight, config.sighShape.baseWdth);
	tail = new circle(pGame, tailref, config.sighShape.baseWdth / 2);
	tip = new Triangle(pGame, tipref, 3, 3, 3, 3, 3, 3, config.sighShape.baseWdth * 0.29 * 3);
}
void pencil::draw() const {
	body->draw();
	tail->draw();
	tip->draw();

}
void pencil::resizeUp()
{
	config.sighShape.baseHeight = config.sighShape.baseHeight * 2;
	config.sighShape.baseWdth = config.sighShape.baseWdth * 2;
}

void pencil::resizeDown()
{
	config.sighShape.baseHeight = config.sighShape.baseHeight / 2;
	config.sighShape.baseWdth = config.sighShape.baseWdth / 2;
}
void pencil::flip()
{

	body->draw();
	point tailref = { RefPoint.x, RefPoint.y - config.sighShape.baseHeight / 2 };
	tail = new circle(pGame, tailref, config.sighShape.baseWdth / 2);
	tail->draw();

	int py1 = 3;
	int py2 = 3;
	int py3 = 3;
	int temp_py = py1;
	py1 = py3;
	py2 = temp_py;
	py3 = temp_py;

	point tipref = { RefPoint.x,RefPoint.y + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 0.29 };
	tip = new Triangle(pGame, tipref, 3, py1, 3, py2, 3, py3, config.sighShape.baseWdth * 0.29 * 3);
	tip->draw();


}
void pencil::rotate()
{
	point bodyref = RefPoint;
	body = new Rect(pGame, bodyref, config.sighShape.baseWdth, config.sighShape.baseHeight);
	body->draw();

	point tailref = { RefPoint.x - config.sighShape.baseHeight / 2, RefPoint.y };
	tail = new circle(pGame, tailref, config.sighShape.baseWdth / 2);
	tail->draw();

	point tipref = { RefPoint.x + config.sighShape.baseHeight / 2 + config.sighShape.baseWdth * 0.29, RefPoint.y };

	int px1 = 3;
	int py1 = 3;
	int px2 = 3;
	int py2 = 3;
	int px3 = 3;
	int py3 = 3;
	int temp_px = px1, temp_py = py1;
	px1 = px3;
	py1 = py3;
	px3 = px2;
	py3 = py2;
	px2 = temp_px;
	py3 = temp_py;
	tip = new Triangle(pGame, tipref, px1, py1, px2, py2, px3, py3, config.sighShape.baseWdth * 0.29 * 3);
	tip->draw();


}