#include "toolbar.h"
#include "game.h"
//#include "grid.h"
	//toolbarItemImages[ITM_circle] = "images\\toolbarItems\\Circle_Icon.jpg";
	//toolbarItemImages[ITM_Triangle] = "images\\toolbarItems\\Triangle_Icon.jpg";
	//toolbarItemImages[ITM_Rectangle] = "images\\toolbarItems\\Rectangle_Icon.jpg";
	//toolbarItemImages[ITM_House] = "images\\toolbarItems\\Rectangle_Icon.jpg";
//toolbarItemImages[ITM_Horse] = "images\\toolbarItems\\.jpg";
////////////////////////////////////////////////////  class toolbar   //////////////////////////////////////////////
toolbar::toolbar(game* pG)
{	
	height = config.toolBarHeight;
	width = config.windWidth;
	this->pGame = pG;
	window* pWind = pGame->getWind();
	
	//You can draw the tool bar icons in any way you want.

	//First prepare List of images for each toolbar item

	toolbarItemImages[ITM_SIGN] = "images\\toolbarItems\\toolbar_sign.jpg";	
	toolbarItemImages[ITM_Car] = "images\\toolbarItems\\Car_Icon.jpg";
	toolbarItemImages[ITM_tree] = "images\\toolbarItems\\Tree_Icon.jpg";
	toolbarItemImages[ITM_lollipop] = "images\\toolbarItems\\Lollipop_Icon.jpg";
	toolbarItemImages[ITM_key] = "images\\toolbarItems\\Key_Icon.jpg";
	toolbarItemImages[ITM_pencil] = "images\\toolbarItems\\Pencil_Icon.jpg";
	toolbarItemImages[ITM_robot] = "images\\toolbarItems\\Robot_Icon.jpg";
	toolbarItemImages[ITM_Increase] = "images\\toolbarItems\\Increase_Sign.jpg";
	toolbarItemImages[ITM_Decrease] = "images\\toolbarItems\\Decrease_Sign.jpg";
	toolbarItemImages[ITM_Refresh] = "images\\toolbarItems\\Refresh_Sign.jpg";
	toolbarItemImages[ITM_Rotate] = "images\\toolbarItems\\Rotate_Sign.jpg";
	toolbarItemImages[ITM_Hint] = "images\\toolbarItems\\Hint_Sign.jpg";
	toolbarItemImages[ITM_Delete] = "images\\toolbarItems\\Delete_Sign.jpg";
	toolbarItemImages[ITM_Save] = "images\\toolbarItems\\Save_Sign.jpg";
	toolbarItemImages[ITM_SelectLevel] = "images\\toolbarItems\\SelectLevel_Sign.jpg";
	toolbarItemImages[ITM_EXIT] = "images\\toolbarItems\\toolbar_Exit.jpg";


	//TODO: Prepare image for each toolbar item and add it to the list

	//Draw toolbar item one image at a time
	int i = 0;
	for (i; i < ITM_CNT; i++)
	{
		pWind->DrawImage(toolbarItemImages[i], i * config.toolbarItemWidth, 0, config.toolbarItemWidth, height);

	}
	int x_integer = ((i * config.toolbarItemWidth) + 55);
	pWind->SetFont(20, BOLD, MODERN, "Arial");
	pWind->SetPen(RED, 1);
	pWind->DrawString(config.toolbarItemWidth * (i), 5, "lives:");
	pWind->DrawInteger(x_integer, 5, pGame->getLives());
	pWind->DrawString(config.toolbarItemWidth * (i), 25, "Level:");
	pWind->DrawInteger(x_integer, 25, pGame->getLvl());
	pWind->DrawString(config.toolbarItemWidth * (i), 45, "Score:");
	pWind->DrawInteger(x_integer, 45, pGame->getScore());


	//Draw a line under the toolbar
	pWind->SetPen(DARKBLUE, 3);
	pWind->DrawLine(0, height, width, height);
}



//handles clicks on toolbar icons, returns ITM_CNT if the click is not inside the toolbar
toolbarItem toolbar::getItemClicked(int x)
{
	
	if (x > ITM_CNT * config.toolbarItemWidth)	//click outside toolbar boundaries
		return ITM_CNT;
	
	
	//Check whick toolbar item was clicked
	//==> This assumes that toolbar items are lined up horizontally <==
	//Divide x coord of the point clicked by the icon width (int division)
	//if division result is 0 ==> first item is clicked, if 1 ==> 2nd item and so on

	return (toolbarItem)(x / config.toolbarItemWidth);

}

